package com.nexora.x.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nexora.x.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexoraRoot(vm: MainViewModel = viewModel()) {
    NexoraTheme {
        val nav = rememberNavController()
        val entry by nav.currentBackStackEntryAsState()
        val current = Screen.fromRoute(entry?.destination?.route)
        val msg by vm.message.collectAsStateWithLifecycle()
        LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

        Scaffold(
            containerColor = NxColors.Obsidian,
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(current.title)) },
                    navigationIcon = {
                        if (current != Screen.Dashboard) IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = NxColors.Obsidian, titleContentColor = NxColors.Cyan, navigationIconContentColor = NxColors.SoftWhite),
                )
            },
        ) { pad ->
            NavHost(nav, startDestination = Screen.Dashboard.route, modifier = Modifier.padding(pad)) {
                composable(Screen.Dashboard.route) { DashboardScreen(vm) { nav.navigate(it.route) } }
                composable(Screen.Library.route) { LibraryScreen(vm) }
                composable(Screen.Session.route) { SessionScreen(vm) }
                composable(Screen.ContextIntel.route) { ContextScreen(vm) }
                composable(Screen.Room.route) { RoomScreen(vm) }
                composable(Screen.Profiles.route) { ProfilesScreen(vm) }
                composable(Screen.Graphics.route) { GraphicsScreen(vm) }
                composable(Screen.Audio.route) { AudioScreen(vm) }
                composable(Screen.Network.route) { NetworkScreen(vm) }
                composable(Screen.Thermal.route) { ThermalScreen(vm) }
                composable(Screen.Lab.route) { LabScreen(vm) }
                composable(Screen.Shizuku.route) { ShizukuScreen(vm) }
                composable(Screen.Settings.route) { SettingsScreen(vm) }
            }
        }
        msg?.let {
            AlertDialog(onDismissRequest = { vm.clearMessage() }, text = { Text(it) },
                confirmButton = { TextButton(onClick = { vm.clearMessage() }) { Text(stringResource(R.string.btn_ok)) } })
        }
    }
}
