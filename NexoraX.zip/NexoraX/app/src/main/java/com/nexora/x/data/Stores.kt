package com.nexora.x.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.Intent
import com.nexora.x.model.*
import com.nexora.x.restore.JournalEntry
import com.nexora.x.restore.JournalStatus
import com.nexora.x.restore.JournalStore
import com.nexora.x.restore.RestoreSummary
import com.nexora.x.session.Aggregate
import com.nexora.x.session.Comparison
import com.nexora.x.session.SessionReport
import com.nexora.x.session.Verdict
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Journal of every system change NEXORA made. commit() (synchronous) because it must survive a crash. */
class JournalPrefsStore(ctx: Context) : JournalStore {
    private val prefs = ctx.getSharedPreferences("nexora_journal", Context.MODE_PRIVATE)

    override fun load(): List<JournalEntry> = try {
        val arr = JSONArray(prefs.getString("entries", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            JournalEntry(
                o.getString("id"), o.getString("original"), o.getString("applied"), o.getLong("at"),
                o.optString("source"), JournalStatus.valueOf(o.getString("status")),
                if (o.has("restoredAt")) o.getLong("restoredAt") else null,
            )
        }
    } catch (_: Exception) { emptyList() }

    override fun save(entries: List<JournalEntry>) {
        val arr = JSONArray()
        entries.forEach {
            arr.put(JSONObject().put("id", it.id).put("original", it.original).put("applied", it.applied)
                .put("at", it.modifiedAtMs).put("source", it.source).put("status", it.status.name)
                .also { o -> it.restoredAtMs?.let { r -> o.put("restoredAt", r) } })
        }
        prefs.edit().putString("entries", arr.toString()).commit()
    }
}

class SettingsStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nexora_settings", Context.MODE_PRIVATE)
    private val _selected = MutableStateFlow(prefs.getString("selected", null))
    val selectedPackage: StateFlow<String?> = _selected
    private val _autoEnd = MutableStateFlow(prefs.getInt("auto_end_min", 10))
    val autoEndMinutes: StateFlow<Int> = _autoEnd

    fun select(pkg: String?) { prefs.edit().putString("selected", pkg).apply(); _selected.value = pkg }
    fun setAutoEnd(min: Int) { prefs.edit().putInt("auto_end_min", min).apply(); _autoEnd.value = min }
}

class ProfileStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nexora_profiles", Context.MODE_PRIVATE)
    private val _profiles = MutableStateFlow(load())
    val profiles: StateFlow<Map<String, GameProfile>> = _profiles

    fun get(pkg: String): GameProfile? = _profiles.value[pkg]

    fun upsert(p: GameProfile) {
        val m = _profiles.value.toMutableMap(); m[p.packageName] = p
        _profiles.value = m
        val arr = JSONArray(); m.values.forEach { arr.put(toJson(it)) }
        prefs.edit().putString("profiles", arr.toString()).apply()
    }

    private fun load(): Map<String, GameProfile> = try {
        val arr = JSONArray(prefs.getString("profiles", "[]"))
        (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }.associateBy { it.packageName }
    } catch (_: Exception) { emptyMap() }

    private fun <T : Enum<T>> JSONObject.enumOr(key: String, default: T, parse: (String) -> T): T =
        try { parse(getString(key)) } catch (_: Exception) { default }

    private fun toJson(p: GameProfile) = JSONObject()
        .put("pkg", p.packageName).put("name", p.displayName).put("enabled", p.optimizationEnabled)
        .put("profile", p.selectedProfile.name).put("detect", p.contextDetectionMode.name)
        .put("graphics", p.graphicsProfile.name).put("thermal", p.thermalPolicy.name).put("audio", p.audioPolicy.name)
        .put("netOn", p.networkPolicy.probeEnabled).put("netHost", p.networkPolicy.host).put("netPort", p.networkPolicy.port)
        .put("rules", JSONArray().also { a -> p.activityRules.forEach { r -> a.put(JSONObject().put("c", r.classContains).put("s", r.state.name)) } })

    private fun fromJson(o: JSONObject): GameProfile {
        val d = GameProfile(o.getString("pkg"), o.optString("name", o.getString("pkg")))
        val rules = o.optJSONArray("rules")?.let { a ->
            (0 until a.length()).mapNotNull {
                try { ActivityRule(a.getJSONObject(it).getString("c"), GameState.valueOf(a.getJSONObject(it).getString("s"))) } catch (_: Exception) { null }
            }
        } ?: emptyList()
        return d.copy(
            optimizationEnabled = o.optBoolean("enabled", true),
            selectedProfile = o.enumOr("profile", d.selectedProfile) { OptimizationProfile.valueOf(it) },
            contextDetectionMode = o.enumOr("detect", d.contextDetectionMode) { ContextDetectionMode.valueOf(it) },
            graphicsProfile = o.enumOr("graphics", d.graphicsProfile) { GraphicsProfile.valueOf(it) },
            thermalPolicy = o.enumOr("thermal", d.thermalPolicy) { ThermalPolicyMode.valueOf(it) },
            audioPolicy = o.enumOr("audio", d.audioPolicy) { AudioPolicy.valueOf(it) },
            networkPolicy = NetworkPolicy(o.optBoolean("netOn", false), o.optString("netHost", ""), o.optInt("netPort", 443)),
            activityRules = rules,
        )
    }
}

data class GameInfo(val packageName: String, val label: String, val versionName: String?, val isGame: Boolean)

class GameRepository(private val ctx: Context) {
    @Suppress("DEPRECATION")
    fun load(): List<GameInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != ctx.packageName }
            .map { ai ->
                val ver = try { pm.getPackageInfo(ai.packageName, 0).versionName } catch (_: Exception) { null }
                GameInfo(ai.packageName, pm.getApplicationLabel(ai).toString(), ver,
                    ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
            }
            .sortedWith(compareByDescending<GameInfo> { it.isGame }.thenBy { it.label.lowercase() })
    }
}

class ReportStore(private val ctx: Context) {
    private val dir get() = File(ctx.filesDir, "reports").apply { mkdirs() }

    fun save(r: SessionReport) { File(dir, "${r.id}.json").writeText(toJson(r).toString()) }

    fun list(): List<SessionReport> = (dir.listFiles() ?: emptyArray())
        .sortedByDescending { it.name }.take(30)
        .mapNotNull { try { fromJson(JSONObject(it.readText())) } catch (_: Exception) { null } }

    fun traceFile(name: String): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, name)

    private fun aggJson(a: Aggregate) = JSONObject().put("n", a.samples)
        .put("jank", a.avgJankPct?.toDouble() ?: JSONObject.NULL).put("mem", a.avgAvailMemMb?.toDouble() ?: JSONObject.NULL)
        .put("lat", a.avgLatencyMs?.toDouble() ?: JSONObject.NULL).put("temp", a.avgBatteryTempC?.toDouble() ?: JSONObject.NULL)
        .put("maxTh", a.maxThermal.name).put("stutter", a.stutterIntervals)

    private fun JSONObject.f(k: String): Float? = if (isNull(k)) null else getDouble(k).toFloat()

    private fun aggFrom(o: JSONObject) = Aggregate(o.getInt("n"), o.f("jank"), o.f("mem"), o.f("lat"), o.f("temp"),
        ThermalLevel.valueOf(o.getString("maxTh")), o.getInt("stutter"))

    private fun toJson(r: SessionReport) = JSONObject()
        .put("id", r.id).put("pkg", r.packageName).put("name", r.displayName).put("start", r.startMs).put("end", r.endMs)
        .put("base", aggJson(r.baseline)).put("opt", aggJson(r.optimized))
        .put("cmp", JSONArray().also { a -> r.comparisons.forEach { c ->
            a.put(JSONObject().put("m", c.metric).put("b", c.before?.toDouble() ?: JSONObject.NULL).put("a", c.after?.toDouble() ?: JSONObject.NULL).put("v", c.verdict.name)) } })
        .put("tis", JSONObject().also { o -> r.timeInStateMs.forEach { (k, v) -> o.put(k.name, v) } })
        .put("actions", JSONArray().also { a -> r.actions.forEach { (id, s) -> a.put(JSONObject().put("id", id).put("s", s.name)) } })
        .put("restore", JSONObject().put("ok", r.restore.restored).put("user", r.restore.userChanged).put("fail", r.restore.failed).put("na", r.restore.unavailable))
        .put("diag", JSONArray(r.diagnoses)).put("notes", JSONArray(r.notes))

    private fun fromJson(o: JSONObject): SessionReport {
        val cmp = o.getJSONArray("cmp"); val acts = o.getJSONArray("actions"); val tis = o.getJSONObject("tis")
        val rs = o.getJSONObject("restore")
        return SessionReport(
            o.getLong("id"), o.getString("pkg"), o.getString("name"), o.getLong("start"), o.getLong("end"),
            aggFrom(o.getJSONObject("base")), aggFrom(o.getJSONObject("opt")),
            (0 until cmp.length()).map { cmp.getJSONObject(it).let { c -> Comparison(c.getString("m"), c.f("b"), c.f("a"), Verdict.valueOf(c.getString("v"))) } },
            tis.keys().asSequence().associate { GameState.valueOf(it) to tis.getLong(it) },
            (0 until acts.length()).map { acts.getJSONObject(it).let { a -> a.getString("id") to ActionStatus.valueOf(a.getString("s")) } },
            RestoreSummary(rs.getInt("ok"), rs.getInt("user"), rs.getInt("fail"), rs.getInt("na")),
            o.getJSONArray("diag").let { a -> (0 until a.length()).map { a.getString(it) } },
            o.getJSONArray("notes").let { a -> (0 until a.length()).map { a.getString(it) } },
        )
    }
}
