package com.nexora.x

import android.app.Application
import com.nexora.x.capability.CapabilityDetector
import com.nexora.x.context.ContextEngine
import com.nexora.x.context.RoomFocusEngine
import com.nexora.x.data.*
import com.nexora.x.monitor.*
import com.nexora.x.restore.RestoreEngine
import com.nexora.x.session.SessionManager
import com.nexora.x.shizuku.ShizukuBridge
import com.nexora.x.thermal.ThermalGuardian
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Manual dependency graph (kept simple and verifiable; see ARCHITECTURE.md for the Hilt/Room decision). */
class AppContainer(val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val bridge = ShizukuBridge(app)
    val thermal = ThermalGuardian(app)
    val network = NetworkGuardian(app)
    val audio = AudioGuardian(app)
    val capabilities = CapabilityDetector(app)
    val restore = RestoreEngine(JournalPrefsStore(app))
    val foreground = ForegroundDetector(app)
    val metrics = MetricsCollector(app, thermal, network, audio, bridge)
    val profiles = ProfileStore(app)
    val games = GameRepository(app)
    val reports = ReportStore(app)
    val settings = SettingsStore(app)
    val context = ContextEngine()
    val room = RoomFocusEngine()
    val session: SessionManager

    init {
        session = SessionManager(this)
        bridge.start(); thermal.start(); network.start(); audio.start()
        session.watchRecovery()
    }
}
