package com.nexora.x

import android.app.Application

class NexoraApp : Application() {
    val container: AppContainer by lazy { AppContainer(this) }

    override fun onCreate() {
        super.onCreate()
        container // eager: starts passive listeners and crash/reboot recovery watching
    }
}
