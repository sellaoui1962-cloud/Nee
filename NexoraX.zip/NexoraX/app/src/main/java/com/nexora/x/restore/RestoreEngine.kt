package com.nexora.x.restore

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class JournalStatus { APPLIED, RESTORED, USER_CHANGED, RESTORE_FAILED }

data class JournalEntry(
    val id: String,
    val original: String,
    val applied: String,
    val modifiedAtMs: Long,
    val source: String,
    val status: JournalStatus,
    val restoredAtMs: Long? = null,
) {
    val pending: Boolean get() = status == JournalStatus.APPLIED || status == JournalStatus.RESTORE_FAILED
}

interface SettingAdapter {
    val id: String
    /** null = unsupported / cannot be read. */
    suspend fun read(): String?
    suspend fun write(value: String): Boolean
}

fun interface AdapterResolver { fun resolve(id: String): SettingAdapter? }

interface JournalStore {
    fun load(): List<JournalEntry>
    fun save(entries: List<JournalEntry>)
}

enum class ApplyResult { APPLIED, ALREADY_SET, UNSUPPORTED, WRITE_FAILED, VERIFY_FAILED_REVERTED, VERIFY_FAILED_REVERT_FAILED }

data class RestoreSummary(val restored: Int = 0, val userChanged: Int = 0, val failed: Int = 0, val unavailable: Int = 0) {
    val allClear: Boolean get() = failed == 0 && unavailable == 0
}

/**
 * Safety-critical: every change = read -> journal original -> write -> verify (revert on mismatch).
 * Restore only touches entries NEXORA wrote, and never overwrites a value the user changed meanwhile.
 * The journal is persisted on every mutation, which gives crash and reboot recovery.
 */
class RestoreEngine(private val store: JournalStore) {
    private val mutex = Mutex()
    private val entries: MutableList<JournalEntry> = store.load().toMutableList()
    @Volatile private var snapshot: List<JournalEntry> = entries.toList()

    fun pendingCount(): Int = snapshot.count { it.pending }
    fun hasPending(): Boolean = pendingCount() > 0
    fun journal(): List<JournalEntry> = snapshot

    private fun persist() {
        // keep only the 50 most recent finished entries to bound storage
        val finished = entries.filter { !it.pending }
        if (finished.size > 50) entries.removeAll(finished.sortedBy { it.modifiedAtMs }.take(finished.size - 50).toSet())
        snapshot = entries.toList()
        store.save(snapshot)
    }

    suspend fun apply(adapter: SettingAdapter, value: String, source: String, nowMs: Long): ApplyResult = mutex.withLock {
        val current = adapter.read() ?: return@withLock ApplyResult.UNSUPPORTED
        val existingIdx = entries.indexOfFirst { it.id == adapter.id && it.pending }
        val existing = entries.getOrNull(existingIdx)
        if (current == value) return@withLock ApplyResult.ALREADY_SET

        var original = current
        if (existing != null) {
            if (current == existing.applied) original = existing.original
            else { entries[existingIdx] = existing.copy(status = JournalStatus.USER_CHANGED); persist() } // user changed it since
        }
        if (!adapter.write(value)) return@withLock ApplyResult.WRITE_FAILED
        if (adapter.read() != value) {
            val reverted = adapter.write(original)
            if (!reverted) {
                entries.removeAll { it.id == adapter.id && it.pending }
                entries += JournalEntry(adapter.id, original, value, nowMs, source, JournalStatus.APPLIED)
                persist()
                return@withLock ApplyResult.VERIFY_FAILED_REVERT_FAILED
            }
            return@withLock ApplyResult.VERIFY_FAILED_REVERTED
        }
        entries.removeAll { it.id == adapter.id && it.pending }
        entries += JournalEntry(adapter.id, original, value, nowMs, source, JournalStatus.APPLIED)
        persist()
        ApplyResult.APPLIED
    }

    suspend fun restoreOne(resolver: AdapterResolver, id: String, nowMs: Long): RestoreSummary = mutex.withLock {
        var s = RestoreSummary()
        entries.filter { it.id == id && it.pending }.forEach { s = merge(s, restoreEntry(resolver, it, nowMs)) }
        persist(); s
    }

    suspend fun restoreAll(resolver: AdapterResolver, nowMs: Long): RestoreSummary = mutex.withLock {
        var s = RestoreSummary()
        entries.filter { it.pending }.forEach { s = merge(s, restoreEntry(resolver, it, nowMs)) }
        persist(); s
    }

    private fun merge(a: RestoreSummary, b: RestoreSummary) =
        RestoreSummary(a.restored + b.restored, a.userChanged + b.userChanged, a.failed + b.failed, a.unavailable + b.unavailable)

    private suspend fun restoreEntry(resolver: AdapterResolver, e: JournalEntry, now: Long): RestoreSummary {
        val idx = entries.indexOf(e)
        val adapter = resolver.resolve(e.id) ?: return RestoreSummary(unavailable = 1) // stays pending
        val current = adapter.read() ?: return RestoreSummary(unavailable = 1)
        return when (current) {
            e.original -> { entries[idx] = e.copy(status = JournalStatus.RESTORED, restoredAtMs = now); RestoreSummary(restored = 1) }
            e.applied -> {
                val ok = adapter.write(e.original) && adapter.read() == e.original
                if (ok) { entries[idx] = e.copy(status = JournalStatus.RESTORED, restoredAtMs = now); RestoreSummary(restored = 1) }
                else { entries[idx] = e.copy(status = JournalStatus.RESTORE_FAILED); RestoreSummary(failed = 1) }
            }
            else -> { entries[idx] = e.copy(status = JournalStatus.USER_CHANGED, restoredAtMs = now); RestoreSummary(userChanged = 1) }
        }
    }
}
