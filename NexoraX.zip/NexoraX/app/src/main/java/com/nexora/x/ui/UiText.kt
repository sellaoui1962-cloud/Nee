package com.nexora.x.ui

import androidx.annotation.StringRes
import com.nexora.x.R
import com.nexora.x.analysis.BottleneckKind
import com.nexora.x.analysis.Confidence
import com.nexora.x.model.*
import com.nexora.x.profiles.ActionIds
import com.nexora.x.session.Verdict
import com.nexora.x.shizuku.ShizukuState

@StringRes fun GameState.res() = when (this) {
    GameState.IDLE -> R.string.gs_idle; GameState.APP_STARTING -> R.string.gs_app_starting; GameState.HOME -> R.string.gs_home
    GameState.LOBBY -> R.string.gs_lobby; GameState.ROOM -> R.string.gs_room; GameState.ROOM_TRANSITION -> R.string.gs_room_transition
    GameState.GAMEPLAY -> R.string.gs_gameplay; GameState.VOICE_CHAT -> R.string.gs_voice_chat; GameState.LOADING -> R.string.gs_loading
    GameState.RESULTS -> R.string.gs_results; GameState.BACKGROUND -> R.string.gs_background; GameState.UNKNOWN -> R.string.gs_unknown
}

@StringRes fun RoomState.res() = when (this) {
    RoomState.ROOM_ENTERING -> R.string.rs_entering; RoomState.ROOM_IDLE -> R.string.rs_idle; RoomState.ROOM_ACTIVE -> R.string.rs_active
    RoomState.ROOM_VOICE_ACTIVE -> R.string.rs_voice_active; RoomState.ROOM_TRANSITION -> R.string.rs_transition
    RoomState.ROOM_EXITING -> R.string.rs_exiting; RoomState.ROOM_UNKNOWN -> R.string.rs_unknown
}

@StringRes fun ThermalLevel.res() = when (this) {
    ThermalLevel.NORMAL -> R.string.th_normal; ThermalLevel.LIGHT -> R.string.th_light; ThermalLevel.MODERATE -> R.string.th_moderate
    ThermalLevel.SEVERE -> R.string.th_severe; ThermalLevel.CRITICAL -> R.string.th_critical
    ThermalLevel.EMERGENCY -> R.string.th_emergency; ThermalLevel.UNKNOWN -> R.string.th_unknown
}

@StringRes fun ActionStatus.res() = when (this) {
    ActionStatus.ACTIVE -> R.string.as_active; ActionStatus.INACTIVE -> R.string.as_inactive; ActionStatus.UNAVAILABLE -> R.string.as_unavailable
    ActionStatus.REQUIRES_PERMISSION -> R.string.as_requires_permission; ActionStatus.FAILED -> R.string.as_failed
}

@StringRes fun OptimizationProfile.res() = when (this) {
    OptimizationProfile.SMART_AUTO -> R.string.op_smart_auto; OptimizationProfile.ROOM_FOCUS -> R.string.op_room_focus
    OptimizationProfile.GAMEPLAY_TURBO -> R.string.op_gameplay_turbo; OptimizationProfile.LOW_HEAT -> R.string.op_low_heat
    OptimizationProfile.VOICE_CHAT -> R.string.op_voice_chat; OptimizationProfile.BATTERY_FRIENDLY -> R.string.op_battery_friendly
    OptimizationProfile.BALANCED -> R.string.op_balanced; OptimizationProfile.CUSTOM -> R.string.op_custom
}

@StringRes fun GraphicsProfile.res() = when (this) {
    GraphicsProfile.BALANCED -> R.string.gp_balanced; GraphicsProfile.PERFORMANCE -> R.string.gp_performance
    GraphicsProfile.BATTERY -> R.string.gp_battery; GraphicsProfile.THERMAL_SAFE -> R.string.gp_thermal_safe
    GraphicsProfile.CUSTOM -> R.string.gp_custom
}

@StringRes fun actionRes(id: String) = when (id) {
    ActionIds.REDUCE_POLLING -> R.string.ac_reduce_polling; ActionIds.SUSPEND_ANALYTICS -> R.string.ac_suspend_analytics
    ActionIds.GAME_MODE -> R.string.ac_game_mode; ActionIds.ADPF -> R.string.ac_adpf
    ActionIds.FRAME_STATS -> R.string.ac_frame_stats; ActionIds.THERMAL_GUARD -> R.string.ac_thermal_guard
    else -> R.string.not_available
}

@StringRes fun BottleneckKind.res() = when (this) {
    BottleneckKind.THERMAL_THROTTLING -> R.string.bk_thermal; BottleneckKind.MEMORY_PRESSURE -> R.string.bk_memory
    BottleneckKind.NETWORK_INSTABILITY -> R.string.bk_network; BottleneckKind.CPU -> R.string.bk_cpu; BottleneckKind.GPU -> R.string.bk_gpu
    BottleneckKind.APP_RENDERING -> R.string.bk_rendering; BottleneckKind.STORAGE -> R.string.bk_storage; BottleneckKind.AUDIO -> R.string.bk_audio
    BottleneckKind.NONE -> R.string.bk_none; BottleneckKind.INSUFFICIENT_DATA -> R.string.bk_insufficient
}

@StringRes fun BottleneckKind.recRes() = when (this) {
    BottleneckKind.THERMAL_THROTTLING -> R.string.rec_thermal; BottleneckKind.MEMORY_PRESSURE -> R.string.rec_memory
    BottleneckKind.NETWORK_INSTABILITY -> R.string.rec_network; BottleneckKind.CPU -> R.string.rec_cpu; BottleneckKind.GPU -> R.string.rec_gpu
    BottleneckKind.APP_RENDERING -> R.string.rec_rendering; BottleneckKind.STORAGE -> R.string.rec_storage; BottleneckKind.AUDIO -> R.string.rec_audio
    BottleneckKind.NONE -> R.string.rec_none; BottleneckKind.INSUFFICIENT_DATA -> R.string.rec_insufficient
}

@StringRes fun Confidence.res() = when (this) {
    Confidence.LOW -> R.string.cf_low; Confidence.MEDIUM -> R.string.cf_medium; Confidence.HIGH -> R.string.cf_high
}

@StringRes fun ShizukuState.res() = when (this) {
    ShizukuState.NOT_INSTALLED -> R.string.sz_not_installed; ShizukuState.NOT_RUNNING -> R.string.sz_not_running
    ShizukuState.UNSUPPORTED_VERSION -> R.string.sz_unsupported; ShizukuState.PERMISSION_REQUIRED -> R.string.sz_permission_required
    ShizukuState.PERMISSION_DENIED -> R.string.sz_permission_denied; ShizukuState.READY -> R.string.sz_ready
}

@StringRes fun Verdict.res() = when (this) {
    Verdict.IMPROVED -> R.string.v_improved; Verdict.WORSE -> R.string.v_worse
    Verdict.NO_CHANGE -> R.string.v_no_change; Verdict.NOT_COMPARABLE -> R.string.v_not_comparable
}

@StringRes fun metricRes(id: String) = when (id) {
    "jank_pct" -> R.string.lbl_jank; "avail_mem_mb" -> R.string.lbl_mem_avail
    "latency_ms" -> R.string.lbl_latency; "battery_temp_c" -> R.string.lbl_battery_temp
    else -> R.string.not_available
}

fun fmt(v: Float?, na: String, suffix: String = ""): String = v?.let { String.format("%.1f%s", it, suffix) } ?: na
fun fmtDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
