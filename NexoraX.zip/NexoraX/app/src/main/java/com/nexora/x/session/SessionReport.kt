package com.nexora.x.session

import com.nexora.x.analysis.Diagnosis
import com.nexora.x.analysis.Metrics
import com.nexora.x.context.StateTransition
import com.nexora.x.model.ActionStatus
import com.nexora.x.model.GameState
import com.nexora.x.model.ThermalLevel
import com.nexora.x.profiles.ActionPlan
import com.nexora.x.restore.RestoreSummary
import java.util.Locale

data class Aggregate(
    val samples: Int,
    val avgJankPct: Float?,
    val avgAvailMemMb: Float?,
    val avgLatencyMs: Float?,
    val avgBatteryTempC: Float?,
    val maxThermal: ThermalLevel,
    val stutterIntervals: Int,
)

enum class Verdict { IMPROVED, WORSE, NO_CHANGE, NOT_COMPARABLE }
data class Comparison(val metric: String, val before: Float?, val after: Float?, val verdict: Verdict)

data class SessionReport(
    val id: Long,
    val packageName: String,
    val displayName: String,
    val startMs: Long,
    val endMs: Long,
    val baseline: Aggregate,
    val optimized: Aggregate,
    val comparisons: List<Comparison>,
    val timeInStateMs: Map<GameState, Long>,
    val actions: List<Pair<String, ActionStatus>>,
    val restore: RestoreSummary,
    val diagnoses: List<String>,
    val notes: List<String>,
) { val durationMs: Long get() = endMs - startMs }

object ReportBuilder {
    const val MIN_SAMPLES = 3
    const val STUTTER_JANK_PCT = 10f

    fun aggregate(list: List<Metrics>): Aggregate {
        fun avg(sel: (Metrics) -> Float?) = list.mapNotNull(sel).takeIf { it.isNotEmpty() }?.average()?.toFloat()
        val maxThermal = list.map { it.thermal }.filter { it != ThermalLevel.UNKNOWN }.maxByOrNull { it.severity } ?: ThermalLevel.UNKNOWN
        return Aggregate(
            samples = list.size,
            avgJankPct = avg { it.jankPct },
            avgAvailMemMb = avg { it.availMemMb?.toFloat() },
            avgLatencyMs = avg { it.latencyMs },
            avgBatteryTempC = avg { it.batteryTempC },
            maxThermal = maxThermal,
            stutterIntervals = list.count { (it.jankPct ?: 0f) >= STUTTER_JANK_PCT },
        )
    }

    /** An "improvement" is only reported when the change exceeds [relThreshold] and [minAbs]. */
    fun verdict(before: Float?, after: Float?, lowerIsBetter: Boolean, relThreshold: Float = 0.10f, minAbs: Float = 0.5f): Verdict {
        if (before == null || after == null) return Verdict.NOT_COMPARABLE
        val diff = after - before
        val rel = if (before == 0f) (if (diff == 0f) 0f else Float.MAX_VALUE) else kotlin.math.abs(diff) / kotlin.math.abs(before)
        if (kotlin.math.abs(diff) < minAbs || rel < relThreshold) return Verdict.NO_CHANGE
        val better = if (lowerIsBetter) diff < 0 else diff > 0
        return if (better) Verdict.IMPROVED else Verdict.WORSE
    }

    fun compare(b: Aggregate, a: Aggregate): List<Comparison> = listOf(
        Comparison("jank_pct", b.avgJankPct, a.avgJankPct, verdict(b.avgJankPct, a.avgJankPct, true, minAbs = 1f)),
        Comparison("avail_mem_mb", b.avgAvailMemMb, a.avgAvailMemMb, verdict(b.avgAvailMemMb, a.avgAvailMemMb, false, minAbs = 50f)),
        Comparison("latency_ms", b.avgLatencyMs, a.avgLatencyMs, verdict(b.avgLatencyMs, a.avgLatencyMs, true, minAbs = 5f)),
        Comparison("battery_temp_c", b.avgBatteryTempC, a.avgBatteryTempC, verdict(b.avgBatteryTempC, a.avgBatteryTempC, true, relThreshold = 0.02f, minAbs = 0.5f)),
    )

    fun timeInState(history: List<StateTransition>, endMs: Long): Map<GameState, Long> {
        val m = LinkedHashMap<GameState, Long>()
        history.forEach { m[it.state] = (m[it.state] ?: 0L) + ((it.exitedAtMs ?: endMs) - it.enteredAtMs).coerceAtLeast(0) }
        return m
    }

    fun build(
        id: Long, pkg: String, name: String, startMs: Long, endMs: Long,
        baseline: List<Metrics>, optimized: List<Metrics>, history: List<StateTransition>,
        actions: List<ActionPlan>, restore: RestoreSummary, diagnoses: List<Diagnosis>,
    ): SessionReport {
        val b = aggregate(baseline); val a = aggregate(optimized)
        val notes = mutableListOf<String>()
        val comparable = b.samples >= MIN_SAMPLES && a.samples >= MIN_SAMPLES
        if (!comparable) notes += "insufficient_samples"
        notes += "conditions_not_controlled" // game state may differ between the two windows
        return SessionReport(
            id, pkg, name, startMs, endMs, b, a,
            if (comparable) compare(b, a) else compare(b, a).map { it.copy(verdict = Verdict.NOT_COMPARABLE) },
            timeInState(history, endMs), actions.map { it.id to it.status }, restore,
            diagnoses.map { it.kind.name }.distinct(), notes,
        )
    }
}

/** Chrome-trace JSON: opens directly in the Perfetto UI (ui.perfetto.dev) as counter tracks + state markers. */
object TraceExporter {
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")
    private fun num(v: Float) = String.format(Locale.ROOT, "%.3f", v)

    fun export(metrics: List<Metrics>, history: List<StateTransition>): String {
        val ev = ArrayList<String>()
        fun counter(name: String, ts: Long, v: Float?) {
            if (v != null) ev += """{"name":"${esc(name)}","ph":"C","ts":${ts * 1000},"pid":1,"tid":1,"args":{"value":${num(v)}}}"""
        }
        metrics.forEach {
            counter("thermal_level", it.atMs, if (it.thermal == ThermalLevel.UNKNOWN) null else it.thermal.severity.toFloat())
            counter("battery_temp_c", it.atMs, it.batteryTempC)
            counter("avail_mem_mb", it.atMs, it.availMemMb?.toFloat())
            counter("jank_pct", it.atMs, it.jankPct)
            counter("latency_ms", it.atMs, it.latencyMs)
        }
        history.forEach {
            ev += """{"name":"state:${it.state.name}","ph":"i","s":"g","ts":${it.enteredAtMs * 1000},"pid":1,"tid":1}"""
        }
        return """{"displayTimeUnit":"ms","traceEvents":[${ev.joinToString(",")}]}"""
    }
}
