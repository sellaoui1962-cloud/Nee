package com.nexora.x.shizuku

import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/** Runs inside the Shizuku-launched shell-identity process. Isolated: it can only execute allowlisted commands. */
class PrivilegedService : IUserService.Stub() {

    override fun destroy() { exitProcess(0) }

    override fun run(joinedArgs: String?): String {
        val args = joinedArgs?.split('\u001f') ?: return "exit=-10\nEMPTY"
        if (!ShellAllowlist.validate(args)) return "exit=-11\nREJECTED_BY_ALLOWLIST"
        return try {
            val p = ProcessBuilder(args).redirectErrorStream(true).start()
            val sb = StringBuilder()
            val reader = thread(start = true) {
                try {
                    p.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(4096)
                        while (true) {
                            val n = r.read(buf)
                            if (n < 0) break
                            if (sb.length < MAX_OUT) sb.append(buf, 0, n)
                        }
                    }
                } catch (_: Exception) { }
            }
            val done = p.waitFor(8, TimeUnit.SECONDS)
            if (!done) p.destroyForcibly()
            reader.join(1_000)
            "exit=${if (done) p.exitValue() else -12}\n$sb"
        } catch (e: Exception) {
            "exit=-13\n${e.message}"
        }
    }

    private companion object { const val MAX_OUT = 200_000 }
}
