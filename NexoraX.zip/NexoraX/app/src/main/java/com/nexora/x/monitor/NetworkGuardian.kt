package com.nexora.x.monitor

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.nexora.x.analysis.LatencySampler
import com.nexora.x.analysis.LatencyStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger

data class NetState(val available: Boolean?, val type: String?)

/**
 * Passive connectivity callback + optional TCP-connect latency probe to a user-chosen endpoint.
 * It never touches the game's traffic. Probing is scheduled by the session according to the context policy.
 */
class NetworkGuardian(private val ctx: Context) {
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val _state = MutableStateFlow(NetState(null, null))
    val state: StateFlow<NetState> = _state
    private val _stats = MutableStateFlow<LatencyStats?>(null)
    val stats: StateFlow<LatencyStats?> = _stats
    val interruptions = AtomicInteger(0)
    private val sampler = LatencySampler(20)
    private var registered = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { _state.value = NetState(true, typeOf(cm.getNetworkCapabilities(network))) }
        override fun onLost(network: Network) { interruptions.incrementAndGet(); _state.value = NetState(false, null) }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { _state.value = NetState(true, typeOf(caps)) }
    }

    fun start() {
        if (registered) return
        try { cm.registerDefaultNetworkCallback(callback); registered = true } catch (_: Exception) { }
    }

    fun reset() { sampler.clear(); _stats.value = null; interruptions.set(0) }

    suspend fun probe(host: String, port: Int, timeoutMs: Int = 2_000) {
        val ms: Float? = withContext(Dispatchers.IO) {
            try {
                val t0 = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
                (System.nanoTime() - t0) / 1_000_000f
            } catch (_: Exception) { null }
        }
        sampler.add(ms)
        _stats.value = sampler.stats()
    }

    private fun typeOf(c: NetworkCapabilities?): String? = when {
        c == null -> null
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
        c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
        else -> "OTHER"
    }
}
