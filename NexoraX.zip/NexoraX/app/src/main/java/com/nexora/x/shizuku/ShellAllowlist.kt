package com.nexora.x.shizuku

/**
 * The ONLY commands NEXORA can ever run with shell identity. Validated twice:
 * in the app (ShizukuBridge) and again inside the privileged process (PrivilegedService).
 */
object ShellAllowlist {
    private val PKG = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
    private val USER = Regex("^[0-9]{1,5}$")
    val MODES = setOf("standard", "performance", "battery")

    fun gameModeSet(pkg: String, mode: String, userId: Int) =
        listOf("cmd", "game", "set", "--mode", mode, "--user", userId.toString(), pkg)

    fun gameModeGet(pkg: String, userId: Int) =
        listOf("cmd", "game", "mode", "--user", userId.toString(), pkg)

    fun gfxInfo(pkg: String) = listOf("dumpsys", "gfxinfo", pkg)

    fun validate(a: List<String>): Boolean = when {
        a.size == 8 && a[0] == "cmd" && a[1] == "game" && a[2] == "set" && a[3] == "--mode" &&
            a[4] in MODES && a[5] == "--user" && USER.matches(a[6]) && PKG.matches(a[7]) -> true
        a.size == 6 && a[0] == "cmd" && a[1] == "game" && a[2] == "mode" && a[3] == "--user" &&
            USER.matches(a[4]) && PKG.matches(a[5]) -> true
        a.size == 3 && a[0] == "dumpsys" && a[1] == "gfxinfo" && PKG.matches(a[2]) -> true
        else -> false
    }
}

/** Tolerant parser: output format of `cmd game mode` differs between Android versions/OEMs. null = cannot tell. */
object GameModeParser {
    private val named = Regex("""(standard|performance|battery|custom)""")
    private val current = Regex("""current[^\n]*?(standard|performance|battery|custom)""")

    fun parse(output: String): String? {
        val t = output.lowercase()
        current.find(t)?.let { return it.groupValues[1] }
        for (line in t.lines().map { it.trim() }) {
            if (line.isEmpty()) continue
            if (named.matches(line)) return line
            line.toIntOrNull()?.let { n ->
                return when (n) { 1 -> "standard"; 2 -> "performance"; 3 -> "battery"; 4 -> "custom"; else -> null }
            }
        }
        return null
    }
}
