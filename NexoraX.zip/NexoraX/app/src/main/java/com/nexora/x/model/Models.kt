package com.nexora.x.model

enum class GameState {
    IDLE, APP_STARTING, HOME, LOBBY, ROOM, ROOM_TRANSITION, GAMEPLAY,
    VOICE_CHAT, LOADING, RESULTS, BACKGROUND, UNKNOWN
}

enum class RoomState {
    ROOM_ENTERING, ROOM_IDLE, ROOM_ACTIVE, ROOM_VOICE_ACTIVE,
    ROOM_TRANSITION, ROOM_EXITING, ROOM_UNKNOWN
}

enum class SignalSource { FOREGROUND_PACKAGE, ACTIVITY_RULE, AUDIO_MODE, MANUAL, GAME_INTEGRATION, SESSION }

enum class OptimizationProfile {
    SMART_AUTO, ROOM_FOCUS, GAMEPLAY_TURBO, LOW_HEAT, VOICE_CHAT, BATTERY_FRIENDLY, BALANCED, CUSTOM
}

enum class GraphicsProfile { BALANCED, PERFORMANCE, BATTERY, THERMAL_SAFE, CUSTOM }

enum class ActionStatus { ACTIVE, INACTIVE, UNAVAILABLE, REQUIRES_PERMISSION, FAILED }

/** Kinds of work NEXORA may do. The context policy decides which are allowed in each game state. */
enum class OpKind { THERMAL_MONITOR, ESSENTIAL_METRICS, FRAME_STATS, GAME_MODE_APPLY, NETWORK_PROBE, ANALYTICS_WRITE, HEAVY_UI }

enum class ThermalLevel(val severity: Int) {
    NORMAL(0), LIGHT(1), MODERATE(2), SEVERE(3), CRITICAL(4), EMERGENCY(5), UNKNOWN(-1);

    /** UNKNOWN is never "at least" anything: we do not invent a severity. */
    fun atLeast(other: ThermalLevel): Boolean = severity >= 0 && severity >= other.severity

    companion object {
        /** Maps android.os.PowerManager.THERMAL_STATUS_* (0..6). */
        fun fromAndroidStatus(status: Int): ThermalLevel = when (status) {
            0 -> NORMAL
            1 -> LIGHT
            2 -> MODERATE
            3 -> SEVERE
            4 -> CRITICAL
            5, 6 -> EMERGENCY
            else -> UNKNOWN
        }
    }
}

/** Values accepted by `cmd game set --mode`. */
enum class GameModeValue(val arg: String) { STANDARD("standard"), PERFORMANCE("performance"), BATTERY("battery") }

enum class ContextDetectionMode { AUTO, MANUAL_ONLY }
enum class ThermalPolicyMode { STANDARD, CONSERVATIVE }
enum class AudioPolicy { PRESERVE, IGNORE }

data class NetworkPolicy(val probeEnabled: Boolean = false, val host: String = "", val port: Int = 443)

/** User-defined rule: if the game's foreground Activity class name contains [classContains], the state is [state]. */
data class ActivityRule(val classContains: String, val state: GameState)

data class GameProfile(
    val packageName: String,
    val displayName: String,
    val optimizationEnabled: Boolean = true,
    val selectedProfile: OptimizationProfile = OptimizationProfile.SMART_AUTO,
    val contextDetectionMode: ContextDetectionMode = ContextDetectionMode.AUTO,
    val graphicsProfile: GraphicsProfile = GraphicsProfile.BALANCED,
    val thermalPolicy: ThermalPolicyMode = ThermalPolicyMode.STANDARD,
    val audioPolicy: AudioPolicy = AudioPolicy.PRESERVE,
    val networkPolicy: NetworkPolicy = NetworkPolicy(),
    val activityRules: List<ActivityRule> = emptyList(),
)
