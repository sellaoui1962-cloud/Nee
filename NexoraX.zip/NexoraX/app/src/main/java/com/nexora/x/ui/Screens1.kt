package com.nexora.x.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.nexora.x.R
import com.nexora.x.model.*
import com.nexora.x.shizuku.ShizukuState
import kotlinx.coroutines.delay

enum class Screen(val route: String, @StringRes val title: Int) {
    Dashboard("dashboard", R.string.s_dashboard), Library("library", R.string.s_library),
    Session("session", R.string.s_session), ContextIntel("context", R.string.s_context),
    Room("room", R.string.s_room), Profiles("profiles", R.string.s_profiles),
    Graphics("graphics", R.string.s_graphics), Audio("audio", R.string.s_audio),
    Network("network", R.string.s_network), Thermal("thermal", R.string.s_thermal),
    Lab("lab", R.string.s_lab), Shizuku("shizuku", R.string.s_shizuku), Settings("settings", R.string.s_settings);

    companion object { fun fromRoute(r: String?) = values().firstOrNull { it.route == r } ?: Dashboard }
}

@Composable
fun DashboardScreen(vm: MainViewModel, onNav: (Screen) -> Unit) {
    val ui by vm.session.collectAsState()
    val sz by vm.shizukuState.collectAsState()
    val th by vm.thermal.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val selPkg by vm.selectedPackage.collectAsState()
    val caps by vm.caps.collectAsState()
    val selected = selPkg?.let { profiles[it] }
    val ctx = LocalContext.current
    val na = naText()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ui.active) { while (ui.active) { delay(1000); now = System.currentTimeMillis() } }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.startSession() }
    val usage = if (ui.active) ui.usageAccess else (caps?.usageAccess ?: true)

    Page {
        if (!usage) NxCard {
            Text(stringResource(R.string.lbl_usage_access_missing), color = NxColors.Orange)
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                Text(stringResource(R.string.btn_grant_usage))
            }
        }
        if (ui.pendingRestore > 0) NxCard {
            Text(stringResource(R.string.lbl_pending_restore, ui.pendingRestore), color = NxColors.Orange)
        }
        NxCard(stringResource(R.string.s_dashboard)) {
            KV(stringResource(R.string.lbl_game), selected?.displayName ?: stringResource(R.string.no_game_selected))
            KV(stringResource(R.string.lbl_state), ui.snapshot?.let { stringResource(it.state.res()) } ?: na)
            KV(stringResource(R.string.lbl_confidence), ui.snapshot?.let { String.format("%.2f", it.confidence) } ?: na)
            KV(stringResource(R.string.lbl_profile), (ui.effectiveProfile ?: selected?.selectedProfile)?.let { stringResource(it.res()) } ?: na)
            KV(stringResource(R.string.lbl_shizuku), stringResource(sz.res()), if (sz == ShizukuState.READY) NxColors.Cyan else NxColors.Orange)
            KV(stringResource(R.string.lbl_thermal), stringResource(th.res()), if (th.atLeast(ThermalLevel.MODERATE)) NxColors.Orange else NxColors.SoftWhite)
            val d = ui.diagnoses.firstOrNull()
            KV(stringResource(R.string.lbl_diagnosis), d?.let { stringResource(it.kind.res()) } ?: na)
            KV(stringResource(R.string.lbl_active_actions), ui.actions.count { it.status == ActionStatus.ACTIVE }.toString())
            KV(stringResource(R.string.lbl_duration), if (ui.active) fmtDuration(now - ui.startedAtMs) else na)
        }
        if (!ui.active) {
            BigButton(stringResource(R.string.start_session), enabled = selected != null) {
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                else vm.startSession()
            }
        } else BigButton(stringResource(R.string.stop_session), danger = true) { vm.stopSession() }
        BigButton(stringResource(R.string.restore_normal), danger = true) { vm.restoreEverything() }
        Screen.values().filter { it != Screen.Dashboard }.forEach { s ->
            OutlinedButton(onClick = { onNav(s) }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(s.title)) }
        }
    }
}

@Composable
fun LibraryScreen(vm: MainViewModel) {
    val games by vm.games.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val selPkg by vm.selectedPackage.collectAsState()
    var query by remember { mutableStateOf("") }
    val filtered = remember(games, query) {
        games.filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.lbl_search)) })
        }
        selPkg?.let { pkg -> profiles[pkg]?.let { p -> item(key = "editor") { GameEditor(p, vm) } } }
        items(filtered, key = { it.packageName }) { g ->
            Card(colors = CardDefaults.cardColors(containerColor = NxColors.Surface),
                modifier = Modifier.fillMaxWidth().clickable { vm.select(g) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppIcon(g.packageName)
                    Column(Modifier.weight(1f)) {
                        Text(g.label)
                        Note(g.packageName)
                        Note("${stringResource(R.string.lbl_version)}: ${g.versionName ?: naText()}")
                    }
                    if (g.isGame) Text(stringResource(R.string.lbl_game_tag), color = NxColors.Purple)
                    if (g.packageName == selPkg) Text("✓", color = NxColors.Cyan)
                }
            }
        }
    }
}

@Composable
private fun GameEditor(p: GameProfile, vm: MainViewModel) {
    NxCard(p.displayName) {
        KV(stringResource(R.string.lbl_package), p.packageName)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.lbl_optimization_enabled), Modifier.weight(1f))
            Switch(checked = p.optimizationEnabled, onCheckedChange = { vm.update(p.copy(optimizationEnabled = it)) })
        }
        Text(stringResource(R.string.lbl_detection_mode)); ChipRow(ContextDetectionMode.values().toList(), p.contextDetectionMode,
            { stringResource(if (it == ContextDetectionMode.AUTO) R.string.dm_auto else R.string.dm_manual) }) { vm.update(p.copy(contextDetectionMode = it)) }
        Text(stringResource(R.string.lbl_thermal_policy)); ChipRow(ThermalPolicyMode.values().toList(), p.thermalPolicy,
            { stringResource(if (it == ThermalPolicyMode.STANDARD) R.string.tp_standard else R.string.tp_conservative) }) { vm.update(p.copy(thermalPolicy = it)) }
        Text(stringResource(R.string.lbl_audio_policy)); ChipRow(AudioPolicy.values().toList(), p.audioPolicy,
            { stringResource(if (it == AudioPolicy.PRESERVE) R.string.ap_preserve else R.string.ap_ignore) }) { vm.update(p.copy(audioPolicy = it)) }
    }
}

@Composable
fun SessionScreen(vm: MainViewModel) {
    val ui by vm.session.collectAsState()
    val na = naText()
    Page {
        if (!ui.active) {
            NxCard { Text(stringResource(R.string.lbl_no_active_session)) }
            ui.lastRestore?.let { r -> NxCard(stringResource(R.string.lbl_restore_result)) {
                KV(stringResource(R.string.lbl_restored), r.restored.toString()); KV(stringResource(R.string.lbl_user_changed), r.userChanged.toString())
                KV(stringResource(R.string.lbl_failed), r.failed.toString()); KV(stringResource(R.string.lbl_unavailable), r.unavailable.toString())
            } }
            return@Page
        }
        NxCard(ui.game?.displayName) {
            KV(stringResource(R.string.lbl_phase), stringResource(when (ui.phase) {
                com.nexora.x.session.Phase.WARMUP -> R.string.ph_warmup
                com.nexora.x.session.Phase.OPTIMIZING -> R.string.ph_optimizing
                com.nexora.x.session.Phase.STOPPING -> R.string.ph_stopping
                else -> R.string.ph_idle
            }))
            KV(stringResource(R.string.lbl_state), ui.snapshot?.let { stringResource(it.state.res()) } ?: na)
            KV(stringResource(R.string.lbl_profile), ui.effectiveProfile?.let { stringResource(it.res()) } ?: na)
            KV(stringResource(R.string.lbl_room_state), stringResource(ui.room.res()))
        }
        NxCard(stringResource(R.string.lbl_actions)) {
            ui.actions.forEach { KV(stringResource(actionRes(it.id)), stringResource(it.status.res()), statusColor(it.status)) }
        }
        NxCard(stringResource(R.string.lbl_measurements)) {
            val m = ui.latest
            KV(stringResource(R.string.lbl_mem_avail), m?.availMemMb?.let { "$it MB" } ?: na)
            KV(stringResource(R.string.lbl_battery_temp), fmt(m?.batteryTempC, na, " °C"))
            KV(stringResource(R.string.lbl_jank), fmt(m?.jankPct, na, " %"))
            KV(stringResource(R.string.lbl_latency), fmt(m?.latencyMs, na, " ms"))
            KV(stringResource(R.string.lbl_cpu), fmt(m?.processCpuPct, na, " %"))
        }
        NxCard(stringResource(R.string.lbl_diagnosis)) {
            ui.diagnoses.forEach { d ->
                KV(stringResource(d.kind.res()), stringResource(d.confidence.res()))
                Note(stringResource(d.kind.recRes()))
                if (d.evidence.isNotEmpty()) Note(d.evidence.joinToString())
            }
        }
        BigButton(stringResource(R.string.stop_session), danger = true) { vm.stopSession() }
    }
}

@Composable
fun ContextScreen(vm: MainViewModel) {
    val ui by vm.session.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val selPkg by vm.selectedPackage.collectAsState()
    val p = selPkg?.let { profiles[it] }
    val na = naText()
    var ruleText by remember { mutableStateOf("") }
    var ruleState by remember { mutableStateOf(GameState.GAMEPLAY) }
    Page {
        val s = ui.snapshot
        NxCard(stringResource(R.string.s_context)) {
            KV(stringResource(R.string.lbl_state), s?.let { stringResource(it.state.res()) } ?: na)
            KV(stringResource(R.string.lbl_confidence), s?.let { String.format("%.2f", it.confidence) } ?: na)
            KV(stringResource(R.string.lbl_source), s?.source?.name ?: na)
            KV(stringResource(R.string.lbl_interval), s?.let { "${it.monitoringIntervalMs / 1000} s" } ?: na)
            if (s != null) {
                Note(stringResource(R.string.lbl_allowed) + ": " + s.allowed.joinToString { it.name })
                Note(stringResource(R.string.lbl_disabled) + ": " + s.disabled.joinToString { it.name })
            }
            Note(stringResource(R.string.context_explain))
        }
        NxCard(stringResource(R.string.lbl_manual_state)) {
            ChipRow(GameState.values().filter { it != GameState.IDLE && it != GameState.BACKGROUND }, ui.manualState,
                { stringResource(it.res()) }, enabled = ui.active) { vm.setManualState(if (ui.manualState == it) null else it) }
        }
        NxCard(stringResource(R.string.lbl_last_activity)) {
            Text(ui.lastActivityClass ?: na)
            Note(stringResource(R.string.lbl_rule_hint))
        }
        if (p != null) NxCard(stringResource(R.string.lbl_rules)) {
            p.activityRules.forEachIndexed { i, r ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${r.classContains} → ${stringResource(r.state.res())}", Modifier.weight(1f))
                    TextButton(onClick = { vm.update(p.copy(activityRules = p.activityRules.filterIndexed { j, _ -> j != i })) }) { Text(stringResource(R.string.btn_delete)) }
                }
            }
            OutlinedTextField(value = ruleText, onValueChange = { ruleText = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.lbl_rule_class)) })
            ChipRow(listOf(GameState.HOME, GameState.LOBBY, GameState.ROOM, GameState.GAMEPLAY, GameState.LOADING, GameState.RESULTS), ruleState,
                { stringResource(it.res()) }) { ruleState = it }
            Button(enabled = ruleText.isNotBlank(), onClick = {
                vm.update(p.copy(activityRules = p.activityRules + ActivityRule(ruleText.trim(), ruleState))); ruleText = ""
            }) { Text(stringResource(R.string.btn_add)) }
        }
        NxCard(stringResource(R.string.lbl_history)) {
            if (ui.history.isEmpty()) Text(na)
            ui.history.asReversed().take(10).forEach { h ->
                KV(stringResource(h.state.res()), String.format("%.2f", h.confidence))
            }
        }
    }
}

@Composable
fun RoomScreen(vm: MainViewModel) {
    val ui by vm.session.collectAsState()
    Page {
        NxCard(stringResource(R.string.s_room)) {
            KV(stringResource(R.string.lbl_room_state), stringResource(ui.room.res()),
                if (ui.room == RoomState.ROOM_ACTIVE || ui.room == RoomState.ROOM_VOICE_ACTIVE) NxColors.Cyan else NxColors.SoftWhite)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.lbl_room_manual_toggle), Modifier.weight(1f))
                Switch(checked = ui.manualRoomFocus, enabled = ui.active, onCheckedChange = { vm.setManualRoom(it) })
            }
            Note(stringResource(R.string.room_explain))
        }
    }
}
