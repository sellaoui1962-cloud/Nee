package com.nexora.x.context

import com.nexora.x.model.GameState
import com.nexora.x.model.RoomState

/**
 * Room-level focus. Automatic only when a reliable signal says ROOM (confidence >= 0.7);
 * otherwise the user can switch it on manually. No private game screen is ever "guessed".
 */
class RoomFocusEngine {
    @Volatile var manualRoomFocus: Boolean = false
    @Volatile var state: RoomState = RoomState.ROOM_UNKNOWN
        private set

    val focusActive: Boolean get() = state == RoomState.ROOM_ACTIVE || state == RoomState.ROOM_VOICE_ACTIVE

    fun reset() { state = RoomState.ROOM_UNKNOWN }

    fun update(snap: ContextSnapshot): RoomState {
        val prev = state
        val inRoom = prev == RoomState.ROOM_ACTIVE || prev == RoomState.ROOM_VOICE_ACTIVE ||
            prev == RoomState.ROOM_ENTERING || prev == RoomState.ROOM_IDLE
        val reliable = snap.confidence >= RELIABLE
        val transient = snap.state == GameState.ROOM_TRANSITION || snap.state == GameState.LOADING ||
            snap.state == GameState.APP_STARTING
        val next = when {
            snap.state == GameState.BACKGROUND || snap.state == GameState.IDLE -> RoomState.ROOM_UNKNOWN
            transient && (manualRoomFocus || inRoom) -> RoomState.ROOM_TRANSITION
            snap.state == GameState.VOICE_CHAT && (manualRoomFocus || inRoom) -> RoomState.ROOM_VOICE_ACTIVE
            manualRoomFocus -> RoomState.ROOM_ACTIVE
            snap.state == GameState.ROOM && reliable ->
                if (prev == RoomState.ROOM_ACTIVE || prev == RoomState.ROOM_VOICE_ACTIVE || prev == RoomState.ROOM_ENTERING)
                    RoomState.ROOM_ACTIVE else RoomState.ROOM_ENTERING
            snap.state == GameState.ROOM -> RoomState.ROOM_IDLE
            inRoom && reliable && (snap.state == GameState.HOME || snap.state == GameState.LOBBY || snap.state == GameState.RESULTS) ->
                RoomState.ROOM_EXITING
            else -> RoomState.ROOM_UNKNOWN
        }
        state = next
        return next
    }

    companion object { const val RELIABLE = 0.7f }
}
