package com.nexora.x.profiles

import com.nexora.x.context.StatePolicy
import com.nexora.x.model.*
import com.nexora.x.thermal.ThermalPolicy

data class DeviceCaps(
    val sdk: Int,
    val gameModeApi: Boolean,
    val thermalApi: Boolean,
    val shizukuReady: Boolean,
    val usageAccess: Boolean,
)

data class ActionPlan(val id: String, val status: ActionStatus)

object ActionIds {
    const val REDUCE_POLLING = "reduce_polling"
    const val SUSPEND_ANALYTICS = "suspend_analytics"
    const val GAME_MODE = "game_mode"
    const val ADPF = "adpf_hint"
    const val FRAME_STATS = "frame_stats"
    const val THERMAL_GUARD = "thermal_guard"
}

object ProfileResolver {
    fun resolve(
        selected: OptimizationProfile,
        state: GameState,
        confidence: Float,
        thermal: ThermalLevel,
        roomFocusActive: Boolean = false,
        conservativeThermal: Boolean = false,
    ): OptimizationProfile {
        val base = if (selected == OptimizationProfile.SMART_AUTO) {
            when {
                roomFocusActive && state != GameState.GAMEPLAY -> OptimizationProfile.ROOM_FOCUS
                confidence < StatePolicy.LOW_CONFIDENCE -> OptimizationProfile.BALANCED // conservative when unsure
                state == GameState.ROOM -> OptimizationProfile.ROOM_FOCUS
                state == GameState.VOICE_CHAT -> OptimizationProfile.VOICE_CHAT
                state == GameState.GAMEPLAY -> OptimizationProfile.GAMEPLAY_TURBO
                else -> OptimizationProfile.BALANCED
            }
        } else selected
        return ThermalPolicy.cap(base, thermal, conservativeThermal)
    }

    /** null = leave the system Game Mode alone (NEXORA only reduces its own workload). */
    fun gameModeFor(effective: OptimizationProfile, graphics: GraphicsProfile): GameModeValue? = when (effective) {
        OptimizationProfile.GAMEPLAY_TURBO -> GameModeValue.PERFORMANCE
        OptimizationProfile.LOW_HEAT, OptimizationProfile.BATTERY_FRIENDLY -> GameModeValue.BATTERY
        OptimizationProfile.CUSTOM -> when (graphics) {
            GraphicsProfile.PERFORMANCE -> GameModeValue.PERFORMANCE
            GraphicsProfile.BATTERY, GraphicsProfile.THERMAL_SAFE -> GameModeValue.BATTERY
            else -> null
        }
        else -> null
    }
}

object ProfileEngine {
    /** Honest action list: only what really exists. ADPF is always UNAVAILABLE for a foreign game. */
    fun plan(
        effective: OptimizationProfile,
        graphics: GraphicsProfile,
        caps: DeviceCaps,
        gameModeStatus: ActionStatus,
    ): List<ActionPlan> {
        val wanted = ProfileResolver.gameModeFor(effective, graphics)
        val suspend = effective in setOf(
            OptimizationProfile.ROOM_FOCUS, OptimizationProfile.GAMEPLAY_TURBO,
            OptimizationProfile.VOICE_CHAT, OptimizationProfile.LOW_HEAT,
        )
        val gm = when {
            wanted == null -> ActionStatus.INACTIVE
            !caps.gameModeApi -> ActionStatus.UNAVAILABLE
            !caps.shizukuReady -> ActionStatus.REQUIRES_PERMISSION
            else -> gameModeStatus
        }
        return listOf(
            ActionPlan(ActionIds.REDUCE_POLLING, ActionStatus.ACTIVE),
            ActionPlan(ActionIds.SUSPEND_ANALYTICS, if (suspend) ActionStatus.ACTIVE else ActionStatus.INACTIVE),
            ActionPlan(ActionIds.GAME_MODE, gm),
            ActionPlan(ActionIds.ADPF, ActionStatus.UNAVAILABLE),
            ActionPlan(ActionIds.FRAME_STATS, if (caps.shizukuReady) ActionStatus.ACTIVE else ActionStatus.REQUIRES_PERMISSION),
            ActionPlan(ActionIds.THERMAL_GUARD, if (caps.thermalApi) ActionStatus.ACTIVE else ActionStatus.UNAVAILABLE),
        )
    }
}
