package com.nexora.x.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.nexora.x.R
import com.nexora.x.model.*
import com.nexora.x.shizuku.ShizukuState
import java.text.DateFormat
import java.util.Date

@Composable
fun ProfilesScreen(vm: MainViewModel) {
    val ui by vm.session.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val selPkg by vm.selectedPackage.collectAsState()
    val p = selPkg?.let { profiles[it] }
    Page {
        if (p == null) { NxCard { Text(stringResource(R.string.no_game_selected)) }; return@Page }
        NxCard(stringResource(R.string.s_profiles) + " — " + p.displayName) {
            ChipRow(OptimizationProfile.values().toList(), p.selectedProfile, { stringResource(it.res()) }) { vm.update(p.copy(selectedProfile = it)) }
            Note(stringResource(R.string.profiles_explain))
        }
        NxCard(stringResource(R.string.lbl_graphics_pref)) {
            ChipRow(GraphicsProfile.values().toList(), p.graphicsProfile, { stringResource(it.res()) }) { vm.update(p.copy(graphicsProfile = it)) }
            Note(stringResource(R.string.graphics_pref_explain))
        }
        NxCard(stringResource(R.string.lbl_actions)) {
            if (ui.actions.isEmpty()) Text(naText())
            ui.actions.forEach { KV(stringResource(actionRes(it.id)), stringResource(it.status.res()), statusColor(it.status)) }
            Note(stringResource(R.string.adpf_note))
        }
    }
}

@Composable
fun GraphicsScreen(vm: MainViewModel) {
    val caps by vm.caps.collectAsState()
    val sz by vm.shizukuState.collectAsState()
    val ui by vm.session.collectAsState()
    val mode by vm.gameModeNow.collectAsState()
    val selPkg by vm.selectedPackage.collectAsState()
    var pending by remember { mutableStateOf<String?>(null) }
    val na = naText()
    LaunchedEffect(selPkg, sz) { if (sz == ShizukuState.READY) vm.refreshGameMode() }
    val canApply = sz == ShizukuState.READY && !ui.active && selPkg != null && (caps?.gameModeApi == true)
    Page {
        NxCard(stringResource(R.string.s_graphics)) {
            KV(stringResource(R.string.lbl_game_mode_api), caps?.gameModeApi?.let { stringResource(if (it) R.string.yes else R.string.no) } ?: na)
            KV(stringResource(R.string.lbl_refresh_rates), caps?.refreshRates?.takeIf { it.isNotEmpty() }?.joinToString { "%.0f".format(it) }?.plus(" Hz") ?: na)
            KV(stringResource(R.string.lbl_game_mode_current), mode ?: na)
            Note(stringResource(R.string.graphics_limits))
        }
        NxCard(stringResource(R.string.lbl_apply_game_mode)) {
            Note(stringResource(R.string.graphics_disclosure))
            listOf("performance" to R.string.gp_performance, "battery" to R.string.gp_battery, "standard" to R.string.gp_balanced).forEach { (arg, label) ->
                OutlinedButton(onClick = { pending = arg }, enabled = canApply, modifier = Modifier.fillMaxWidth()) { Text(stringResource(label)) }
            }
            if (!canApply) Note(stringResource(R.string.graphics_unavailable))
        }
    }
    pending?.let { arg ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(stringResource(R.string.lbl_apply_game_mode)) },
            text = { Text(stringResource(R.string.graphics_disclosure)) },
            confirmButton = { TextButton(onClick = { vm.applyGameMode(arg); pending = null }) { Text(stringResource(R.string.btn_apply)) } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text(stringResource(R.string.btn_cancel)) } },
        )
    }
}

@Composable
fun AudioScreen(vm: MainViewModel) {
    val comm by vm.audioComm.collectAsState()
    val ui by vm.session.collectAsState()
    Page {
        NxCard(stringResource(R.string.s_audio)) {
            KV(stringResource(R.string.lbl_audio_mode), stringResource(if (comm) R.string.yes else R.string.no))
            KV(stringResource(R.string.lbl_audio_events), ui.latest?.audioInterruptions?.toString() ?: naText())
            Note(stringResource(R.string.audio_explain))
        }
    }
}

@Composable
fun NetworkScreen(vm: MainViewModel) {
    val ns by vm.netState.collectAsState()
    val st by vm.netStats.collectAsState()
    val profiles by vm.profiles.collectAsState()
    val selPkg by vm.selectedPackage.collectAsState()
    val p = selPkg?.let { profiles[it] }
    val na = naText()
    var host by remember(p?.packageName) { mutableStateOf(p?.networkPolicy?.host ?: "") }
    var port by remember(p?.packageName) { mutableStateOf((p?.networkPolicy?.port ?: 443).toString()) }
    Page {
        NxCard(stringResource(R.string.s_network)) {
            KV(stringResource(R.string.lbl_net_available), ns.available?.let { stringResource(if (it) R.string.yes else R.string.no) } ?: na)
            KV(stringResource(R.string.lbl_net_type), ns.type ?: na)
            KV(stringResource(R.string.lbl_latency), fmt(st?.avgMs, na, " ms"))
            KV(stringResource(R.string.lbl_jitter), fmt(st?.jitterMs, na, " ms"))
            KV(stringResource(R.string.lbl_loss), fmt(st?.lossPct, na, " %"))
            Note(stringResource(R.string.network_explain))
        }
        if (p != null) NxCard(stringResource(R.string.lbl_probe_policy)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.lbl_probe_enabled), Modifier.weight(1f))
                Switch(checked = p.networkPolicy.probeEnabled, onCheckedChange = { vm.update(p.copy(networkPolicy = p.networkPolicy.copy(probeEnabled = it))) })
            }
            OutlinedTextField(value = host, onValueChange = { host = it.trim() }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.lbl_endpoint_host)) })
            OutlinedTextField(value = port, onValueChange = { port = it.filter(Char::isDigit).take(5) }, singleLine = true, modifier = Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.lbl_endpoint_port)) })
            Button(onClick = { vm.update(p.copy(networkPolicy = p.networkPolicy.copy(host = host, port = port.toIntOrNull()?.coerceIn(1, 65535) ?: 443))) }) { Text(stringResource(R.string.btn_apply)) }
        }
    }
}

@Composable
fun ThermalScreen(vm: MainViewModel) {
    val th by vm.thermal.collectAsState()
    val ui by vm.session.collectAsState()
    Page {
        NxCard(stringResource(R.string.s_thermal)) {
            KV(stringResource(R.string.lbl_thermal), stringResource(th.res()), if (th.atLeast(ThermalLevel.MODERATE)) NxColors.Orange else NxColors.Cyan)
            KV(stringResource(R.string.lbl_battery_temp), fmt(ui.latest?.batteryTempC, naText(), " °C"))
            Note(stringResource(R.string.thermal_explain))
        }
    }
}

@Composable
fun LabScreen(vm: MainViewModel) {
    val ui by vm.session.collectAsState()
    val reports by vm.reports.collectAsState()
    val report = ui.lastReport ?: reports.firstOrNull()
    val na = naText()
    Page {
        if (report == null) NxCard { Text(stringResource(R.string.lbl_no_reports)) }
        else NxCard(report.displayName) {
            KV(stringResource(R.string.lbl_duration), fmtDuration(report.durationMs))
            KV(stringResource(R.string.lbl_baseline) + " / " + stringResource(R.string.lbl_after), "${report.baseline.samples} / ${report.optimized.samples}")
            report.comparisons.forEach { c ->
                Text(stringResource(metricRes(c.metric)), color = NxColors.Cyan)
                KV(stringResource(R.string.lbl_baseline) + " → " + stringResource(R.string.lbl_after),
                    "${fmt(c.before, na)} → ${fmt(c.after, na)}  (${stringResource(c.verdict.res())})")
            }
            KV(stringResource(R.string.lbl_stutters), "${report.baseline.stutterIntervals} → ${report.optimized.stutterIntervals}")
            KV(stringResource(R.string.lbl_thermal), "${stringResource(report.baseline.maxThermal.res())} → ${stringResource(report.optimized.maxThermal.res())}")
            report.timeInStateMs.forEach { (s, ms) -> KV(stringResource(s.res()), fmtDuration(ms)) }
            Note(stringResource(R.string.lbl_actions) + ": " + report.actions.joinToString { "${stringResource(actionRes(it.first))}=${stringResource(it.second.res())}" })
            if ("insufficient_samples" in report.notes) Note(stringResource(R.string.lab_insufficient))
        }
        Note(stringResource(R.string.lbl_limits_note))
        OutlinedButton(onClick = { vm.exportTrace() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.btn_export_trace)) }
        if (reports.isNotEmpty()) NxCard(stringResource(R.string.lbl_reports)) {
            reports.forEach { r -> KV(r.displayName, DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(r.startMs))) }
        }
    }
}

@Composable
fun ShizukuScreen(vm: MainViewModel) {
    val sz by vm.shizukuState.collectAsState()
    val log by vm.shizukuLog.collectAsState()
    val journal by vm.journal.collectAsState()
    Page {
        NxCard(stringResource(R.string.s_shizuku)) {
            KV(stringResource(R.string.lbl_shizuku), stringResource(sz.res()), if (sz == ShizukuState.READY) NxColors.Cyan else NxColors.Orange)
            Note(stringResource(R.string.sz_explain))
            if (sz == ShizukuState.PERMISSION_REQUIRED || sz == ShizukuState.PERMISSION_DENIED)
                Button(onClick = { vm.requestShizuku() }) { Text(stringResource(R.string.btn_request_permission)) }
            OutlinedButton(onClick = { vm.refresh() }) { Text(stringResource(R.string.btn_refresh)) }
        }
        NxCard(stringResource(R.string.lbl_journal)) {
            if (journal.isEmpty()) Text(naText())
            journal.takeLast(10).forEach { KV(it.id, "${it.original} → ${it.applied} [${it.status.name}]") }
        }
        NxCard(stringResource(R.string.lbl_op_log)) {
            if (log.isEmpty()) Text(naText())
            log.take(15).forEach { Note(it) }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val autoEnd by vm.autoEnd.collectAsState()
    val caps by vm.caps.collectAsState()
    val ui by vm.session.collectAsState()
    val ctx = LocalContext.current
    Page {
        NxCard(stringResource(R.string.lbl_autoend_minutes)) {
            ChipRow(listOf(0, 5, 10, 30), autoEnd, { if (it == 0) stringResource(R.string.lbl_never) else "$it" }) { vm.setAutoEnd(it) }
        }
        NxCard(stringResource(R.string.lbl_usage_access)) {
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                Text(stringResource(R.string.btn_grant_usage))
            }
        }
        NxCard(stringResource(R.string.lbl_restore_everything)) {
            Text(stringResource(R.string.lbl_pending_restore, ui.pendingRestore))
            BigButton(stringResource(R.string.restore_everything), danger = true) { vm.restoreEverything() }
        }
        NxCard(stringResource(R.string.lbl_capabilities)) {
            Text(caps?.toText() ?: naText(), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { vm.refresh() }) { Text(stringResource(R.string.btn_refresh)) }
        }
        Note(stringResource(R.string.lbl_language_note))
        Note(stringResource(R.string.lbl_privacy_note))
    }
}
