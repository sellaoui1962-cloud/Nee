package com.nexora.x.analysis

import com.nexora.x.model.ThermalLevel
import java.util.Locale

/** Every measurement is nullable: null means NOT AVAILABLE. Nothing is ever simulated. */
data class Metrics(
    val atMs: Long,
    val availMemMb: Long? = null,
    val totalMemMb: Long? = null,
    val lowMemory: Boolean? = null,
    val thermal: ThermalLevel = ThermalLevel.UNKNOWN,
    val batteryTempC: Float? = null,
    val networkAvailable: Boolean? = null,
    val networkType: String? = null,
    val latencyMs: Float? = null,
    val jitterMs: Float? = null,
    val lossPct: Float? = null,
    /** Percentage of janky frames over the last interval (from dumpsys gfxinfo deltas). */
    val jankPct: Float? = null,
    val frameP95Ms: Float? = null,
    val audioInterruptions: Int? = null,
    /** Not measurable for another app without root on modern Android; kept for future/manual sources. */
    val processCpuPct: Float? = null,
    val gpuUtilPct: Float? = null,
)

data class FrameStats(
    val totalFrames: Long,
    val jankyFrames: Long,
    val p50Ms: Int?, val p90Ms: Int?, val p95Ms: Int?, val p99Ms: Int?,
)

object GfxInfoParser {
    private val total = Regex("""Total frames rendered:\s*(\d+)""")
    private val janky = Regex("""Janky frames:\s*(\d+)""")

    fun parse(text: String): FrameStats? {
        val t = total.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: return null
        val j = janky.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: return null
        if (t <= 0) return null
        fun pct(n: Int) = Regex("""${n}th percentile:\s*(\d+)ms""").find(text)?.groupValues?.get(1)?.toIntOrNull()
        return FrameStats(t, j, pct(50), pct(90), pct(95), pct(99))
    }

    /** Janky-frame percentage between two cumulative dumps. null if not enough new frames. */
    fun intervalJankPct(prev: FrameStats?, cur: FrameStats, minFrames: Long = 30): Float? {
        if (prev == null || cur.totalFrames < prev.totalFrames) return null
        val dTotal = cur.totalFrames - prev.totalFrames
        if (dTotal < minFrames) return null
        val dJank = (cur.jankyFrames - prev.jankyFrames).coerceAtLeast(0)
        return dJank * 100f / dTotal
    }
}

enum class BottleneckKind { THERMAL_THROTTLING, MEMORY_PRESSURE, NETWORK_INSTABILITY, CPU, GPU, APP_RENDERING, STORAGE, AUDIO, NONE, INSUFFICIENT_DATA }
enum class Confidence { LOW, MEDIUM, HIGH }
data class Diagnosis(val kind: BottleneckKind, val confidence: Confidence, val evidence: List<String>)

/**
 * Rule based diagnosis. Honest limits: CPU/GPU are only diagnosed when a real number exists;
 * a frame problem with no other cause is reported as APP_RENDERING with LOW confidence (cause indeterminate).
 */
object BottleneckAnalyzer {
    private fun f(v: Float) = String.format(Locale.ROOT, "%.1f", v)

    fun analyze(samples: List<Metrics>): List<Diagnosis> {
        val last = samples.lastOrNull() ?: return listOf(Diagnosis(BottleneckKind.INSUFFICIENT_DATA, Confidence.LOW, emptyList()))
        val jank = samples.takeLast(5).mapNotNull { it.jankPct }.takeIf { it.isNotEmpty() }?.average()?.toFloat()
        val out = mutableListOf<Diagnosis>()

        if (last.thermal.atLeast(ThermalLevel.SEVERE)) {
            out += Diagnosis(BottleneckKind.THERMAL_THROTTLING, Confidence.HIGH, listOf("thermal=${last.thermal}"))
        } else if (last.thermal.atLeast(ThermalLevel.MODERATE)) {
            val c = if (jank != null && jank >= 10f) Confidence.HIGH else Confidence.MEDIUM
            out += Diagnosis(BottleneckKind.THERMAL_THROTTLING, c, listOf("thermal=${last.thermal}"))
        }

        val avail = last.availMemMb
        val total = last.totalMemMb
        val availPct = if (avail != null && total != null && total > 0) avail * 100f / total else null
        if (last.lowMemory == true) {
            out += Diagnosis(BottleneckKind.MEMORY_PRESSURE, Confidence.HIGH, listOf("lowMemory=true"))
        } else if (availPct != null && availPct < 10f) {
            out += Diagnosis(BottleneckKind.MEMORY_PRESSURE, Confidence.MEDIUM, listOf("availMem=${f(availPct)}%"))
        }

        val lat = last.latencyMs; val jit = last.jitterMs; val loss = last.lossPct
        if (last.networkAvailable == false) {
            out += Diagnosis(BottleneckKind.NETWORK_INSTABILITY, Confidence.HIGH, listOf("network=unavailable"))
        } else if ((lat != null && lat > 200f) || (loss != null && loss > 5f) || (jit != null && jit > 80f)) {
            out += Diagnosis(BottleneckKind.NETWORK_INSTABILITY, Confidence.HIGH, listOfNotNull(lat?.let { "latency=${f(it)}ms" }, loss?.let { "loss=${f(it)}%" }, jit?.let { "jitter=${f(it)}ms" }))
        } else if ((lat != null && lat > 120f) || (loss != null && loss > 2f) || (jit != null && jit > 40f)) {
            out += Diagnosis(BottleneckKind.NETWORK_INSTABILITY, Confidence.MEDIUM, listOfNotNull(lat?.let { "latency=${f(it)}ms" }, loss?.let { "loss=${f(it)}%" }, jit?.let { "jitter=${f(it)}ms" }))
        }

        last.processCpuPct?.let { if (it >= 90f) out += Diagnosis(BottleneckKind.CPU, Confidence.MEDIUM, listOf("cpu=${f(it)}%")) }
        last.gpuUtilPct?.let { if (it >= 95f) out += Diagnosis(BottleneckKind.GPU, Confidence.MEDIUM, listOf("gpu=${f(it)}%")) }

        val audio = last.audioInterruptions
        if (audio != null && audio >= 3) out += Diagnosis(BottleneckKind.AUDIO, Confidence.MEDIUM, listOf("audioInterruptions=$audio"))

        if (out.isEmpty()) {
            if (jank != null && jank >= 10f) {
                out += Diagnosis(BottleneckKind.APP_RENDERING, Confidence.LOW, listOf("jank=${f(jank)}%"))
            } else {
                val hasData = jank != null || last.thermal != ThermalLevel.UNKNOWN || avail != null || last.networkAvailable != null
                out += if (hasData) Diagnosis(BottleneckKind.NONE, Confidence.MEDIUM, emptyList())
                else Diagnosis(BottleneckKind.INSUFFICIENT_DATA, Confidence.LOW, emptyList())
            }
        }
        return out.sortedByDescending { it.confidence.ordinal }
    }
}

/** Rolling latency window: jitter = mean |delta| of consecutive successful samples, loss = failed/total. */
data class LatencyStats(val avgMs: Float?, val jitterMs: Float?, val lossPct: Float?, val count: Int)

class LatencySampler(private val window: Int = 20) {
    private val samples = ArrayDeque<Float?>()

    @Synchronized fun add(ms: Float?) { samples.addLast(ms); while (samples.size > window) samples.removeFirst() }
    @Synchronized fun clear() = samples.clear()

    @Synchronized fun stats(): LatencyStats {
        if (samples.isEmpty()) return LatencyStats(null, null, null, 0)
        val ok = samples.filterNotNull()
        val loss = (samples.size - ok.size) * 100f / samples.size
        val avg = if (ok.isEmpty()) null else ok.average().toFloat()
        val jitter = if (ok.size < 2) null else ok.zipWithNext { a, b -> kotlin.math.abs(b - a) }.average().toFloat()
        return LatencyStats(avg, jitter, loss, samples.size)
    }
}
