package com.nexora.x.thermal

import com.nexora.x.model.OptimizationProfile
import com.nexora.x.model.ThermalLevel

/** Thermal protection is never disabled; this only makes NEXORA back off when the device heats up. */
object ThermalPolicy {
    fun cap(p: OptimizationProfile, level: ThermalLevel, conservative: Boolean = false): OptimizationProfile {
        val severeEnough = level.atLeast(if (conservative) ThermalLevel.MODERATE else ThermalLevel.SEVERE)
        if (severeEnough) {
            return if (p == OptimizationProfile.BATTERY_FRIENDLY || p == OptimizationProfile.LOW_HEAT) p
            else OptimizationProfile.LOW_HEAT
        }
        if (level.atLeast(ThermalLevel.MODERATE) || (conservative && level.atLeast(ThermalLevel.LIGHT))) {
            return if (p == OptimizationProfile.GAMEPLAY_TURBO) OptimizationProfile.BALANCED else p
        }
        return p
    }

    fun allowsAggressive(level: ThermalLevel) = !level.atLeast(ThermalLevel.MODERATE)
}
