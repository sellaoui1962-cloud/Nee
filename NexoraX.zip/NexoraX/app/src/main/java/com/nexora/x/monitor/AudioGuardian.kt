package com.nexora.x.monitor

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.atomic.AtomicInteger

/**
 * Observation only. AudioManager.mode == MODE_IN_COMMUNICATION is a moderate-confidence hint of voice chat
 * (any VoIP app causes it). Output-device removals are counted as "audio route interruptions".
 * NEXORA never opens audio sessions or changes audio settings.
 */
class AudioGuardian(private val ctx: Context) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val _inCommunication = MutableStateFlow(false)
    val inCommunication: StateFlow<Boolean> = _inCommunication
    val interruptions = AtomicInteger(0)
    private var registered = false

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) { interruptions.incrementAndGet() }
    }

    fun start() {
        if (registered) return
        am.registerAudioDeviceCallback(deviceCallback, null)
        registered = true
    }

    fun resetCounters() = interruptions.set(0)

    fun refresh() { _inCommunication.value = am.mode == AudioManager.MODE_IN_COMMUNICATION }
}
