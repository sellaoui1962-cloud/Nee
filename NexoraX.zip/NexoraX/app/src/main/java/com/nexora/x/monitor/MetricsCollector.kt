package com.nexora.x.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.nexora.x.analysis.FrameStats
import com.nexora.x.analysis.GfxInfoParser
import com.nexora.x.analysis.Metrics
import com.nexora.x.shizuku.ShellAllowlist
import com.nexora.x.shizuku.ShizukuBridge
import com.nexora.x.shizuku.ShizukuState
import com.nexora.x.thermal.ThermalGuardian

/** Collects only real values. Anything the platform does not expose to a normal app stays null. */
class MetricsCollector(
    private val ctx: Context,
    private val thermal: ThermalGuardian,
    private val network: NetworkGuardian,
    private val audio: AudioGuardian,
    private val bridge: ShizukuBridge,
) {
    private var prevFrames: FrameStats? = null
    private var prevPkg: String? = null

    fun resetFrames() { prevFrames = null; prevPkg = null }

    suspend fun collect(pkg: String, nowMs: Long, wantFrames: Boolean): Metrics {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val bat: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temp = if (tenths != null && tenths != Int.MIN_VALUE) tenths / 10f else null

        var jank: Float? = null
        var p95: Float? = null
        if (wantFrames && bridge.state.value == ShizukuState.READY) {
            val r = bridge.run(ShellAllowlist.gfxInfo(pkg))
            val cur = if (r.ok) GfxInfoParser.parse(r.output) else null
            if (cur != null) {
                if (prevPkg == pkg) jank = GfxInfoParser.intervalJankPct(prevFrames, cur)
                p95 = cur.p95Ms?.toFloat()
                prevFrames = cur; prevPkg = pkg
            }
        }

        val net = network.state.value
        val st = network.stats.value
        return Metrics(
            atMs = nowMs,
            availMemMb = mi.availMem / (1024 * 1024),
            totalMemMb = mi.totalMem.takeIf { it > 0 }?.div(1024 * 1024),
            lowMemory = mi.lowMemory,
            thermal = thermal.level.value,
            batteryTempC = temp,
            networkAvailable = net.available,
            networkType = net.type,
            latencyMs = st?.avgMs, jitterMs = st?.jitterMs, lossPct = st?.lossPct,
            jankPct = jank, frameP95Ms = p95,
            audioInterruptions = audio.interruptions.get(),
        )
    }
}
