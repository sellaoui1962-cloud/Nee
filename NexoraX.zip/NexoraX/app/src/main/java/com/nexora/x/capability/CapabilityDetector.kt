package com.nexora.x.capability

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process
import android.view.Display
import com.nexora.x.profiles.DeviceCaps
import rikka.shizuku.Shizuku

data class CapabilityReport(
    val sdk: Int,
    val release: String,
    val manufacturer: String,
    val model: String,
    val totalRamMb: Long?,
    val thermalApi: Boolean,
    val performanceHintApi: Boolean,
    val gameModeApi: Boolean,
    val shizukuInstalled: Boolean,
    val shizukuRunning: Boolean,
    val shizukuPermission: Boolean,
    val usageAccess: Boolean,
    val refreshRates: List<Float>,
) {
    fun toText(): String = buildString {
        appendLine("Android $release (SDK $sdk) — $manufacturer $model")
        appendLine("RAM: ${totalRamMb ?: "NOT AVAILABLE"} MB")
        appendLine("Thermal API: $thermalApi | PerformanceHintManager: $performanceHintApi | Game Mode API: $gameModeApi")
        appendLine("Shizuku installed=$shizukuInstalled running=$shizukuRunning permission=$shizukuPermission")
        appendLine("Usage access: $usageAccess")
        appendLine("Refresh rates: ${if (refreshRates.isEmpty()) "NOT AVAILABLE" else refreshRates.joinToString { "%.0f".format(it) }} Hz")
    }
}

class CapabilityDetector(private val ctx: Context) {

    @Suppress("DEPRECATION")
    fun detect(): CapabilityReport {
        val sdk = Build.VERSION.SDK_INT
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val installed = try { ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true } catch (_: Exception) { false }
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        val perm = try { running && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        val rates = try {
            val d: Display? = if (Build.VERSION.SDK_INT >= 30) ctx.display else (ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay
            d?.supportedModes?.map { it.refreshRate }?.distinct()?.sorted() ?: emptyList()
        } catch (_: Throwable) { emptyList() }
        return CapabilityReport(
            sdk = sdk, release = Build.VERSION.RELEASE, manufacturer = Build.MANUFACTURER, model = Build.MODEL,
            totalRamMb = mi.totalMem.takeIf { it > 0 }?.div(1024 * 1024),
            thermalApi = sdk >= 29,
            performanceHintApi = sdk >= 31 && ctx.getSystemService("performance_hint") != null,
            gameModeApi = sdk >= 31,
            shizukuInstalled = installed, shizukuRunning = running, shizukuPermission = perm,
            usageAccess = hasUsageAccess(ctx),
            refreshRates = rates,
        )
    }

    fun deviceCaps(shizukuReady: Boolean): DeviceCaps = DeviceCaps(
        sdk = Build.VERSION.SDK_INT, gameModeApi = Build.VERSION.SDK_INT >= 31, thermalApi = Build.VERSION.SDK_INT >= 29,
        shizukuReady = shizukuReady, usageAccess = hasUsageAccess(ctx),
    )

    companion object {
        @Suppress("DEPRECATION")
        fun hasUsageAccess(ctx: Context): Boolean {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29)
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }
}
