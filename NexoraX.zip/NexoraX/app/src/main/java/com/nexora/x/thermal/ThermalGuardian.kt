package com.nexora.x.thermal

import android.content.Context
import android.os.Build
import android.os.PowerManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.nexora.x.model.ThermalLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Passive listener on the official Thermal API (Android 10+). Below that the level stays UNKNOWN. */
class ThermalGuardian(private val ctx: Context) {
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val _level = MutableStateFlow(ThermalLevel.UNKNOWN)
    val level: StateFlow<ThermalLevel> = _level
    private var listener: Any? = null

    fun start() { if (Build.VERSION.SDK_INT >= 29) startApi29() }
    fun stop() { if (Build.VERSION.SDK_INT >= 29) stopApi29() }

    @RequiresApi(29)
    private fun startApi29() {
        if (listener != null) return
        _level.value = ThermalLevel.fromAndroidStatus(pm.currentThermalStatus)
        val l = PowerManager.OnThermalStatusChangedListener { _level.value = ThermalLevel.fromAndroidStatus(it) }
        listener = l
        pm.addThermalStatusListener(ContextCompat.getMainExecutor(ctx), l)
    }

    @RequiresApi(29)
    private fun stopApi29() {
        (listener as? PowerManager.OnThermalStatusChangedListener)?.let { pm.removeThermalStatusListener(it) }
        listener = null
    }
}
