package com.nexora.x.monitor

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import com.nexora.x.capability.CapabilityDetector

data class ForegroundInfo(val isForeground: Boolean?, val className: String?)

/**
 * Foreground detection through UsageStatsManager (requires the user to grant Usage access).
 * Also exposes the foreground Activity class name, which feeds the user-defined activity rules.
 */
class ForegroundDetector(private val ctx: Context) {
    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private var currentPkg: String? = null
    private var currentClass: String? = null
    private var primed = false
    private var lastQuery = 0L

    fun hasAccess() = CapabilityDetector.hasUsageAccess(ctx)

    fun reset() { currentPkg = null; currentClass = null; primed = false; lastQuery = 0 }

    @Suppress("DEPRECATION")
    fun poll(pkg: String, nowMs: Long): ForegroundInfo {
        if (!hasAccess()) return ForegroundInfo(null, null)
        val from = if (!primed) nowMs - 10 * 60_000L else lastQuery - 1_000L
        val events = usm.queryEvents(from, nowMs)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> { currentPkg = e.packageName; currentClass = e.className }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (e.packageName == currentPkg) { currentPkg = null; currentClass = null }
                SCREEN_NON_INTERACTIVE -> { currentPkg = null; currentClass = null }
            }
        }
        primed = true
        lastQuery = nowMs
        val fg = currentPkg == pkg
        return ForegroundInfo(fg, if (fg) currentClass else null)
    }

    private companion object { const val SCREEN_NON_INTERACTIVE = 17 }
}
