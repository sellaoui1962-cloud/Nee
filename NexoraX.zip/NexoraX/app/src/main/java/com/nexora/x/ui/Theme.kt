package com.nexora.x.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object NxColors {
    val Obsidian = Color(0xFF0A0A0F)
    val Surface = Color(0xFF14141C)
    val Cyan = Color(0xFF00E5FF)
    val Purple = Color(0xFFB026FF)
    val SoftWhite = Color(0xFFF2F4F8)
    val Orange = Color(0xFFFF8A3D)
    val Red = Color(0xFFFF3B3B)
}

private val scheme = darkColorScheme(
    primary = NxColors.Cyan, onPrimary = NxColors.Obsidian,
    secondary = NxColors.Purple, onSecondary = NxColors.SoftWhite,
    tertiary = NxColors.Orange, error = NxColors.Red,
    background = NxColors.Obsidian, onBackground = NxColors.SoftWhite,
    surface = NxColors.Surface, onSurface = NxColors.SoftWhite,
    surfaceVariant = NxColors.Surface, onSurfaceVariant = NxColors.SoftWhite,
)

@Composable
fun NexoraTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = scheme, content = content)
