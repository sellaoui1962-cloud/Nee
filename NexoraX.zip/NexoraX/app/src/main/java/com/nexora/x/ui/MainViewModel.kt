package com.nexora.x.ui

import android.app.Application
import android.os.Process
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexora.x.NexoraApp
import com.nexora.x.capability.CapabilityReport
import com.nexora.x.data.GameInfo
import com.nexora.x.model.GameProfile
import com.nexora.x.model.GameState
import com.nexora.x.restore.JournalEntry
import com.nexora.x.session.SessionReport
import com.nexora.x.shizuku.GameModeAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as NexoraApp).container
    private val userId = Process.myUid() / 100_000

    val session = c.session.ui
    val shizukuState = c.bridge.state
    val shizukuLog = c.bridge.log
    val thermal = c.thermal.level
    val netState = c.network.state
    val netStats = c.network.stats
    val audioComm = c.audio.inCommunication
    val profiles = c.profiles.profiles
    val selectedPackage = c.settings.selectedPackage
    val autoEnd = c.settings.autoEndMinutes

    val games = MutableStateFlow<List<GameInfo>>(emptyList())
    val caps = MutableStateFlow<CapabilityReport?>(null)
    val reports = MutableStateFlow<List<SessionReport>>(emptyList())
    val journal = MutableStateFlow<List<JournalEntry>>(emptyList())
    val gameModeNow = MutableStateFlow<String?>(null)
    val message = MutableStateFlow<String?>(null)

    init { refresh() }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            c.bridge.refresh()
            games.value = c.games.load()
            caps.value = c.capabilities.detect()
            reports.value = c.reports.list()
            journal.value = c.restore.journal()
        }
    }

    fun select(info: GameInfo) {
        if (c.profiles.get(info.packageName) == null) c.profiles.upsert(GameProfile(info.packageName, info.label))
        c.settings.select(info.packageName)
    }

    fun update(p: GameProfile) = c.profiles.upsert(p)
    fun startSession() { selectedPackage.value?.let { pkg -> c.profiles.get(pkg)?.let { c.session.start(it) } } }
    fun stopSession() = c.session.stop()
    fun restoreEverything() { c.session.restoreEverything(); refresh() }
    fun setManualState(s: GameState?) = c.session.setManualState(s)
    fun setManualRoom(on: Boolean) = c.session.setManualRoomFocus(on)
    fun requestShizuku() = c.bridge.requestPermission()
    fun setAutoEnd(min: Int) = c.settings.setAutoEnd(min)

    fun refreshGameMode() {
        val pkg = selectedPackage.value ?: return
        viewModelScope.launch(Dispatchers.IO) { gameModeNow.value = GameModeAdapter(c.bridge, pkg, userId).read() }
    }

    /** Manual, user-confirmed Game Mode change. Goes through the RestoreEngine, so it is journaled and reversible. */
    fun applyGameMode(arg: String) {
        val pkg = selectedPackage.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val r = c.restore.apply(GameModeAdapter(c.bridge, pkg, userId), arg, "manual_graphics", System.currentTimeMillis())
            message.value = r.name
            gameModeNow.value = GameModeAdapter(c.bridge, pkg, userId).read()
            journal.value = c.restore.journal()
        }
    }

    fun exportTrace() {
        viewModelScope.launch(Dispatchers.IO) {
            val f = c.reports.traceFile("nexora_trace_${System.currentTimeMillis()}.json")
            f.writeText(c.session.exportTrace())
            message.value = f.absolutePath
        }
    }

    fun clearMessage() { message.value = null }
}
