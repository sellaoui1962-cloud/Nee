package com.nexora.x.context

import com.nexora.x.model.GameState
import com.nexora.x.model.OpKind
import com.nexora.x.model.SignalSource

data class ContextSignal(
    val source: SignalSource,
    val state: GameState?,
    val confidence: Float,
    val atMs: Long,
    /** 0 = never expires (until cleared). */
    val ttlMs: Long = 30_000L,
    /** Only set by foreground detection. null = "no information". */
    val gameForeground: Boolean? = null,
)

data class ContextSnapshot(
    val state: GameState,
    val confidence: Float,
    val source: SignalSource,
    val enteredAtMs: Long,
    val gameForeground: Boolean?,
    val monitoringIntervalMs: Long,
    val allowed: Set<OpKind>,
    val disabled: Set<OpKind>,
    val networkProbeIntervalMs: Long?,
)

data class StateTransition(
    val state: GameState,
    val confidence: Float,
    val source: SignalSource,
    val enteredAtMs: Long,
    val exitedAtMs: Long? = null,
)

object StatePolicy {
    const val LOW_CONFIDENCE = 0.5f

    private val IN_GAME_STABLE = setOf(
        GameState.HOME, GameState.LOBBY, GameState.ROOM, GameState.VOICE_CHAT,
        GameState.GAMEPLAY, GameState.RESULTS, GameState.UNKNOWN,
    )
    private val QUIET_UI = setOf(GameState.IDLE, GameState.HOME, GameState.LOBBY, GameState.RESULTS, GameState.BACKGROUND)

    fun monitoringIntervalMs(state: GameState): Long = when (state) {
        GameState.IDLE -> 10_000
        GameState.HOME, GameState.LOBBY, GameState.RESULTS -> 5_000
        GameState.APP_STARTING, GameState.LOADING, GameState.ROOM_TRANSITION -> 10_000
        GameState.ROOM, GameState.VOICE_CHAT -> 15_000
        GameState.GAMEPLAY -> 10_000
        GameState.BACKGROUND -> 30_000
        GameState.UNKNOWN -> 10_000
    }

    fun networkProbeIntervalMs(state: GameState, confidence: Float): Long? = when (state) {
        GameState.HOME, GameState.LOBBY, GameState.RESULTS ->
            if (confidence < LOW_CONFIDENCE) 60_000 else 15_000
        GameState.UNKNOWN, GameState.APP_STARTING, GameState.IDLE -> 60_000
        else -> null // never ping during room / gameplay / voice / loading / background
    }

    fun allowedOps(state: GameState, confidence: Float): Set<OpKind> {
        val s = mutableSetOf(OpKind.THERMAL_MONITOR, OpKind.ESSENTIAL_METRICS)
        if (state in IN_GAME_STABLE) {
            s += OpKind.FRAME_STATS
            s += OpKind.GAME_MODE_APPLY
        }
        if (state in QUIET_UI) {
            s += OpKind.ANALYTICS_WRITE
            s += OpKind.HEAVY_UI
        }
        // Low confidence => we may actually be mid-game: never do "quiet time" work.
        if (confidence < LOW_CONFIDENCE) {
            s -= OpKind.ANALYTICS_WRITE
            s -= OpKind.HEAVY_UI
        }
        if (networkProbeIntervalMs(state, confidence) != null) s += OpKind.NETWORK_PROBE
        return s
    }
}

/**
 * Multi-source state machine. Never invents a screen: with only "game is foreground" it reports UNKNOWN (0.25).
 * Time is passed in explicitly, so the engine is deterministic and unit-testable.
 */
class ContextEngine {
    private val lock = Any()
    private var active = false
    private var foreground: Boolean? = null
    private var foregroundSince = 0L
    private var seenNotForeground = false
    private val signals = HashMap<SignalSource, ContextSignal>()
    private var current: ContextSnapshot? = null
    private val history = ArrayList<StateTransition>()

    fun startSession(nowMs: Long) = synchronized(lock) {
        active = true; foreground = null; foregroundSince = 0; seenNotForeground = false
        signals.clear(); current = null; history.clear()
        evaluateLocked(nowMs)
        Unit
    }

    fun endSession(nowMs: Long) = synchronized(lock) {
        active = false
        evaluateLocked(nowMs)
        closeLast(nowMs)
        Unit
    }

    fun submit(signal: ContextSignal) = synchronized(lock) {
        signal.gameForeground?.let { fg ->
            if (fg && foreground != true) foregroundSince = signal.atMs
            if (!fg) {
                seenNotForeground = true
                signals.keys.removeAll { it != SignalSource.MANUAL }
            }
            foreground = fg
        }
        if (signal.state != null) signals[signal.source] = signal
        Unit
    }

    fun clear(source: SignalSource) = synchronized(lock) { signals.remove(source); Unit }

    fun evaluate(nowMs: Long): ContextSnapshot = synchronized(lock) { evaluateLocked(nowMs) }

    fun history(): List<StateTransition> = synchronized(lock) { history.toList() }

    private fun decide(now: Long): Triple<GameState, Float, SignalSource> {
        if (!active) return Triple(GameState.IDLE, 1f, SignalSource.SESSION)
        if (foreground == false) return Triple(GameState.BACKGROUND, 0.9f, SignalSource.FOREGROUND_PACKAGE)
        val best = signals.values
            .filter { it.state != null && (it.ttlMs <= 0 || now - it.atMs <= it.ttlMs) }
            .maxWithOrNull(compareBy<ContextSignal>({ it.source == SignalSource.MANUAL }, { it.confidence }))
        if (best != null) return Triple(best.state!!, best.confidence, best.source)
        return if (foreground == true) {
            if (seenNotForeground && now - foregroundSince < APP_START_WINDOW_MS)
                Triple(GameState.APP_STARTING, 0.6f, SignalSource.FOREGROUND_PACKAGE)
            else Triple(GameState.UNKNOWN, 0.25f, SignalSource.FOREGROUND_PACKAGE)
        } else Triple(GameState.UNKNOWN, 0.1f, SignalSource.SESSION)
    }

    private fun build(state: GameState, conf: Float, src: SignalSource, entered: Long) = ContextSnapshot(
        state = state, confidence = conf, source = src, enteredAtMs = entered, gameForeground = foreground,
        monitoringIntervalMs = StatePolicy.monitoringIntervalMs(state),
        allowed = StatePolicy.allowedOps(state, conf),
        disabled = OpKind.values().toSet() - StatePolicy.allowedOps(state, conf),
        networkProbeIntervalMs = StatePolicy.networkProbeIntervalMs(state, conf),
    )

    private fun evaluateLocked(now: Long): ContextSnapshot {
        val (state, conf, src) = decide(now)
        val prev = current
        val snap = if (prev != null && prev.state == state) {
            build(state, conf, src, prev.enteredAtMs)
        } else {
            closeLast(now)
            history += StateTransition(state, conf, src, now)
            build(state, conf, src, now)
        }
        current = snap
        return snap
    }

    private fun closeLast(now: Long) {
        val i = history.lastIndex
        if (i >= 0 && history[i].exitedAtMs == null) history[i] = history[i].copy(exitedAtMs = now)
    }

    companion object { const val APP_START_WINDOW_MS = 5_000L }
}

object ActivityRuleMatcher {
    fun match(className: String?, rules: List<com.nexora.x.model.ActivityRule>): GameState? {
        if (className.isNullOrBlank()) return null
        return rules.firstOrNull { it.classContains.isNotBlank() && className.contains(it.classContains, ignoreCase = true) }?.state
    }
}
