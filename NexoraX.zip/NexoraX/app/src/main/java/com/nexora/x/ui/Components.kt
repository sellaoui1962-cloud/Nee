package com.nexora.x.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.nexora.x.R
import com.nexora.x.model.ActionStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp), content = content,
)

@Composable
fun NxCard(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = NxColors.Surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (title != null) Text(title, color = NxColors.Cyan, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun KV(k: String, v: String, valueColor: Color = NxColors.SoftWhite) = Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(k, Modifier.weight(1f), color = Color(0xFF9AA0AE))
    Spacer(Modifier.width(8.dp))
    Text(v, color = valueColor, fontWeight = FontWeight.Medium)
}

@Composable
fun Note(text: String) = Text(text, color = Color(0xFF9AA0AE), style = MaterialTheme.typography.bodySmall)

fun statusColor(s: ActionStatus) = when (s) {
    ActionStatus.ACTIVE -> NxColors.Cyan
    ActionStatus.FAILED -> NxColors.Red
    ActionStatus.REQUIRES_PERMISSION -> NxColors.Orange
    ActionStatus.UNAVAILABLE -> Color(0xFF6B7080)
    ActionStatus.INACTIVE -> NxColors.SoftWhite
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChipRow(items: List<T>, selected: T?, label: @Composable (T) -> String, enabled: Boolean = true, onClick: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { FilterChip(selected = it == selected, enabled = enabled, onClick = { onClick(it) }, label = { Text(label(it)) }) }
    }
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, danger: Boolean = false, onClick: () -> Unit) = Button(
    onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(52.dp),
    colors = ButtonDefaults.buttonColors(
        containerColor = if (danger) NxColors.Orange else NxColors.Cyan,
        contentColor = NxColors.Obsidian,
    ),
) { Text(text, fontWeight = FontWeight.Bold) }

@Composable
fun AppIcon(pkg: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, pkg) {
        value = withContext(Dispatchers.IO) {
            try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (_: Exception) { null }
        }
    }
    val b = bmp
    if (b != null) Image(b, null, Modifier.size(40.dp)) else Spacer(Modifier.size(40.dp))
}

@Composable fun naText() = stringResource(R.string.not_available)
