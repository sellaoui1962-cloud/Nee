package com.nexora.x.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.nexora.x.restore.SettingAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

enum class ShizukuState { NOT_INSTALLED, NOT_RUNNING, UNSUPPORTED_VERSION, PERMISSION_REQUIRED, PERMISSION_DENIED, READY }

data class ShellResult(val exit: Int, val output: String) { val ok: Boolean get() = exit == 0 }

/**
 * Wrapper over the official Shizuku API. Shizuku is NOT root: commands run as the ADB "shell" user,
 * and only commands in [ShellAllowlist] are ever sent.
 */
class ShizukuBridge(private val context: Context) {
    private val _state = MutableStateFlow(ShizukuState.NOT_RUNNING)
    val state: StateFlow<ShizukuState> = _state

    private val _log = MutableStateFlow<List<String>>(emptyList())
    val log: StateFlow<List<String>> = _log

    @Volatile private var service: IUserService? = null
    private val mutex = Mutex()
    private var started = false
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.ROOT)

    private val onBinderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val onBinderDead = Shizuku.OnBinderDeadListener { service = null; refresh() }
    private val onPermission = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    fun start() {
        if (started) return
        started = true
        Shizuku.addBinderReceivedListenerSticky(onBinderReceived)
        Shizuku.addBinderDeadListener(onBinderDead)
        Shizuku.addRequestPermissionResultListener(onPermission)
        refresh()
    }

    @Suppress("DEPRECATION")
    fun refresh() {
        val installed = try { context.packageManager.getPackageInfo(SHIZUKU_PKG, 0); true } catch (_: Exception) { false }
        val s = try {
            when {
                !Shizuku.pingBinder() -> if (installed) ShizukuState.NOT_RUNNING else ShizukuState.NOT_INSTALLED
                Shizuku.isPreV11() -> ShizukuState.UNSUPPORTED_VERSION
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> ShizukuState.READY
                Shizuku.shouldShowRequestPermissionRationale() -> ShizukuState.PERMISSION_DENIED
                else -> ShizukuState.PERMISSION_REQUIRED
            }
        } catch (_: Throwable) {
            if (installed) ShizukuState.NOT_RUNNING else ShizukuState.NOT_INSTALLED
        }
        if (s != ShizukuState.READY) service = null
        _state.value = s
    }

    fun requestPermission() {
        val s = _state.value
        if (s == ShizukuState.PERMISSION_REQUIRED || s == ShizukuState.PERMISSION_DENIED) {
            try { Shizuku.requestPermission(REQUEST_CODE) } catch (e: Throwable) { log("requestPermission failed: ${e.message}") }
        }
    }

    suspend fun run(args: List<String>): ShellResult {
        if (!ShellAllowlist.validate(args)) return ShellResult(-1, "REJECTED_BY_ALLOWLIST").also { log("REJECTED ${args.take(3)}") }
        if (_state.value != ShizukuState.READY) return ShellResult(-2, "SHIZUKU_NOT_READY")
        val svc = ensureService() ?: return ShellResult(-3, "SERVICE_UNAVAILABLE").also { log("service unavailable") }
        return withContext(Dispatchers.IO) {
            try {
                val raw = svc.run(args.joinToString("\u001f"))
                val nl = raw.indexOf('\n')
                val exit = raw.substring(0, if (nl < 0) raw.length else nl).removePrefix("exit=").toIntOrNull() ?: -5
                val out = if (nl < 0) "" else raw.substring(nl + 1)
                // log without output (may be large); only command head + exit code
                log("${args.take(3).joinToString(" ")} … exit=$exit")
                ShellResult(exit, out)
            } catch (e: Throwable) {
                service = null
                log("binder error: ${e.message}")
                ShellResult(-4, e.message ?: "binder error")
            }
        }
    }

    private suspend fun ensureService(): IUserService? = mutex.withLock {
        service?.let { if (it.asBinder().pingBinder()) return@withLock it }
        val args = Shizuku.UserServiceArgs(ComponentName(context.packageName, PrivilegedService::class.java.name))
            .daemon(false).processNameSuffix("shell").version(1)
        withTimeoutOrNull(6_000) {
            suspendCancellableCoroutine<IUserService?> { cont ->
                val conn = object : ServiceConnection {
                    override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                        val s = if (binder != null && binder.pingBinder()) IUserService.Stub.asInterface(binder) else null
                        service = s
                        if (cont.isActive) cont.resume(s)
                    }
                    override fun onServiceDisconnected(name: ComponentName?) { service = null; refresh() }
                }
                try { Shizuku.bindUserService(args, conn) } catch (e: Throwable) {
                    log("bindUserService failed: ${e.message}")
                    if (cont.isActive) cont.resume(null)
                }
            }
        }
    }

    private fun log(line: String) {
        _log.value = (listOf("${timeFmt.format(Date())} $line") + _log.value).take(50)
    }

    companion object {
        const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
        private const val REQUEST_CODE = 4242
    }
}

/** System Game Mode (Android 12+) of one package, driven through `cmd game`. */
class GameModeAdapter(private val bridge: ShizukuBridge, private val pkg: String, private val userId: Int) : SettingAdapter {
    override val id = idFor(pkg)

    override suspend fun read(): String? {
        val r = bridge.run(ShellAllowlist.gameModeGet(pkg, userId))
        return if (r.ok) GameModeParser.parse(r.output) else null
    }

    override suspend fun write(value: String): Boolean = bridge.run(ShellAllowlist.gameModeSet(pkg, value, userId)).ok

    companion object {
        const val PREFIX = "game_mode:"
        fun idFor(pkg: String) = PREFIX + pkg
    }
}
