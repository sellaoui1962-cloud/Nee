package com.nexora.x.session

import android.os.Build
import android.os.Process
import com.nexora.x.AppContainer
import com.nexora.x.analysis.BottleneckAnalyzer
import com.nexora.x.analysis.Diagnosis
import com.nexora.x.analysis.Metrics
import com.nexora.x.context.*
import com.nexora.x.model.*
import com.nexora.x.profiles.*
import com.nexora.x.restore.AdapterResolver
import com.nexora.x.restore.ApplyResult
import com.nexora.x.restore.RestoreSummary
import com.nexora.x.shizuku.GameModeAdapter
import com.nexora.x.shizuku.ShizukuState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class Phase { IDLE, WARMUP, OPTIMIZING, STOPPING }

data class SessionUiState(
    val active: Boolean = false,
    val phase: Phase = Phase.IDLE,
    val game: GameProfile? = null,
    val snapshot: ContextSnapshot? = null,
    val room: RoomState = RoomState.ROOM_UNKNOWN,
    val effectiveProfile: OptimizationProfile? = null,
    val actions: List<ActionPlan> = emptyList(),
    val latest: Metrics? = null,
    val diagnoses: List<Diagnosis> = emptyList(),
    val startedAtMs: Long = 0,
    val lastActivityClass: String? = null,
    val history: List<StateTransition> = emptyList(),
    val lastReport: SessionReport? = null,
    val pendingRestore: Int = 0,
    val manualRoomFocus: Boolean = false,
    val manualState: GameState? = null,
    val usageAccess: Boolean = true,
    val lastRestore: RestoreSummary? = null,
)

/**
 * Orchestrates one gaming session:
 *  select -> warm-up baseline -> apply profile (via RestoreEngine) -> adaptive loop -> restore + report.
 * The loop interval comes from the context policy, so NEXORA's own workload shrinks in room / gameplay.
 */
class SessionManager(private val c: AppContainer) {
    private val _ui = MutableStateFlow(SessionUiState(pendingRestore = c.restore.pendingCount()))
    val ui: StateFlow<SessionUiState> = _ui

    private val userId = Process.myUid() / 100_000
    private val stopMutex = Mutex()
    private var job: Job? = null

    private val baseline = ArrayList<Metrics>()
    private val optimized = ArrayList<Metrics>()
    private val recent = ArrayDeque<Metrics>()
    private var appliedArg: String? = null
    private var lastAttemptArg: String? = null
    private var gameModeStatus = ActionStatus.INACTIVE
    private var fgSince: Long? = null
    private var bgSince: Long? = null
    private var lastProbeAt = 0L
    private var tickCount = 0
    private var manualState: GameState? = null
    private var lastPlan: List<ActionPlan> = emptyList()
    private var lastDiagnoses: List<Diagnosis> = emptyList()

    val resolver = AdapterResolver { id ->
        if (id.startsWith(GameModeAdapter.PREFIX) && c.bridge.state.value == ShizukuState.READY)
            GameModeAdapter(c.bridge, id.removePrefix(GameModeAdapter.PREFIX), userId) else null
    }

    /** Crash / reboot / Shizuku-reconnect recovery: whenever Shizuku becomes READY and nothing is running, restore leftovers. */
    fun watchRecovery() {
        c.scope.launch {
            c.bridge.state.collect { s ->
                if (s == ShizukuState.READY && !_ui.value.active && c.restore.hasPending()) restoreEverythingNow()
            }
        }
    }

    fun start(game: GameProfile) {
        if (_ui.value.active) return
        val now = System.currentTimeMillis()
        baseline.clear(); optimized.clear(); recent.clear()
        appliedArg = null; lastAttemptArg = null; gameModeStatus = ActionStatus.INACTIVE
        fgSince = null; bgSince = null; lastProbeAt = 0; tickCount = 0; manualState = null
        lastPlan = emptyList(); lastDiagnoses = emptyList()
        c.context.startSession(now); c.room.reset(); c.room.manualRoomFocus = false
        c.network.reset(); c.audio.resetCounters(); c.foreground.reset(); c.metrics.resetFrames()
        c.bridge.refresh()
        _ui.value = SessionUiState(
            active = true, phase = Phase.WARMUP, game = game, startedAtMs = now,
            usageAccess = c.foreground.hasAccess(), pendingRestore = c.restore.pendingCount(),
            lastReport = _ui.value.lastReport,
        )
        SessionService.start(c.app)
        job = c.scope.launch {
            while (isActive) {
                var interval = 10_000L
                try { interval = tick(game) } catch (e: CancellationException) { throw e } catch (_: Exception) { }
                delay(interval)
            }
        }
    }

    fun setManualState(state: GameState?) {
        manualState = state
        val now = System.currentTimeMillis()
        if (state == null) c.context.clear(SignalSource.MANUAL)
        else c.context.submit(ContextSignal(SignalSource.MANUAL, state, 1.0f, now, ttlMs = 0))
        _ui.update { it.copy(manualState = state) }
    }

    fun setManualRoomFocus(on: Boolean) {
        c.room.manualRoomFocus = on
        _ui.update { it.copy(manualRoomFocus = on) }
    }

    private suspend fun tick(game: GameProfile): Long {
        val now = System.currentTimeMillis()
        tickCount++

        val fg = c.foreground.poll(game.packageName, now)
        if (fg.isForeground != null) c.context.submit(ContextSignal(SignalSource.FOREGROUND_PACKAGE, null, 0.9f, now, gameForeground = fg.isForeground))
        if (game.contextDetectionMode == ContextDetectionMode.AUTO) {
            val st = ActivityRuleMatcher.match(fg.className, game.activityRules)
            if (st != null) c.context.submit(ContextSignal(SignalSource.ACTIVITY_RULE, st, 0.8f, now, ttlMs = 0))
            else c.context.clear(SignalSource.ACTIVITY_RULE)
        }
        c.audio.refresh()
        if (game.audioPolicy == AudioPolicy.PRESERVE && c.audio.inCommunication.value && fg.isForeground == true)
            c.context.submit(ContextSignal(SignalSource.AUDIO_MODE, GameState.VOICE_CHAT, 0.6f, now, ttlMs = 0))
        else c.context.clear(SignalSource.AUDIO_MODE)

        val snap = c.context.evaluate(now)
        val room = c.room.update(snap)
        val fgOk = snap.gameForeground == true || (snap.gameForeground == null && snap.source == SignalSource.MANUAL)
        val thermal = c.thermal.level.value
        val eff = ProfileResolver.resolve(
            game.selectedProfile, snap.state, snap.confidence, thermal, c.room.focusActive,
            game.thermalPolicy == ThermalPolicyMode.CONSERVATIVE,
        )

        val m = c.metrics.collect(game.packageName, now, wantFrames = OpKind.FRAME_STATS in snap.allowed && fgOk && tickCount % 2 == 0)
        recent.addLast(m); while (recent.size > 12) recent.removeFirst()
        val phase = _ui.value.phase
        var newPhase = phase
        if (phase == Phase.WARMUP) {
            if (fgOk) { if (fgSince == null) fgSince = now; baseline += m }
            val s = fgSince
            if (s != null && now - s >= WARMUP_MS && baseline.size >= 2) newPhase = Phase.OPTIMIZING
        } else if (phase == Phase.OPTIMIZING) optimized += m
        if (baseline.size > 600) baseline.removeAt(0)
        if (optimized.size > 2000) optimized.removeAt(0)

        val caps = c.capabilities.deviceCaps(c.bridge.state.value == ShizukuState.READY)
        if (newPhase == Phase.OPTIMIZING && game.optimizationEnabled) applyGameMode(game, eff, snap, thermal, fgOk, caps, now)
        val plan = ProfileEngine.plan(eff, game.graphicsProfile, caps, gameModeStatus)
        val diag = BottleneckAnalyzer.analyze(recent.toList())
        lastPlan = plan; lastDiagnoses = diag

        val np = game.networkPolicy
        val probeEvery = snap.networkProbeIntervalMs
        if (np.probeEnabled && np.host.isNotBlank() && OpKind.NETWORK_PROBE in snap.allowed && probeEvery != null && now - lastProbeAt >= probeEvery) {
            lastProbeAt = now
            c.scope.launch { c.network.probe(np.host, np.port) }
        }

        _ui.update {
            it.copy(
                phase = newPhase, snapshot = snap, room = room, effectiveProfile = eff, actions = plan, latest = m,
                diagnoses = diag, lastActivityClass = fg.className ?: it.lastActivityClass, history = c.context.history().takeLast(30),
                pendingRestore = c.restore.pendingCount(), usageAccess = c.foreground.hasAccess(),
            )
        }

        // auto-end when the game has been away for too long
        if (snap.gameForeground == false) {
            val b = bgSince ?: now.also { bgSince = it }
            val limit = c.settings.autoEndMinutes.value
            if (limit > 0 && now - b > limit * 60_000L) { stop(); return 60_000L }
        } else bgSince = null

        return snap.monitoringIntervalMs
    }

    private suspend fun applyGameMode(
        game: GameProfile, eff: OptimizationProfile, snap: ContextSnapshot, thermal: ThermalLevel,
        fgOk: Boolean, caps: DeviceCaps, now: Long,
    ) {
        val allow = (OpKind.GAME_MODE_APPLY in snap.allowed && fgOk) || thermal.atLeast(ThermalLevel.SEVERE)
        if (!allow || !caps.gameModeApi) return
        val desired = ProfileResolver.gameModeFor(eff, game.graphicsProfile)
        val adapter = GameModeAdapter(c.bridge, game.packageName, userId)
        if (desired == null) {
            if (appliedArg != null) {
                c.restore.restoreOne(resolver, adapter.id, now)
                appliedArg = null; lastAttemptArg = null; gameModeStatus = ActionStatus.INACTIVE
            }
            return
        }
        if (desired.arg == appliedArg || desired.arg == lastAttemptArg) return
        if (!caps.shizukuReady) { gameModeStatus = ActionStatus.REQUIRES_PERMISSION; return }
        lastAttemptArg = desired.arg
        val res = c.restore.apply(adapter, desired.arg, "profile:${eff.name}", now)
        gameModeStatus = when (res) {
            ApplyResult.APPLIED, ApplyResult.ALREADY_SET -> ActionStatus.ACTIVE
            ApplyResult.UNSUPPORTED -> ActionStatus.UNAVAILABLE
            else -> ActionStatus.FAILED
        }
        if (res == ApplyResult.APPLIED || res == ApplyResult.ALREADY_SET) appliedArg = desired.arg
    }

    fun stop() {
        c.scope.launch {
            stopMutex.withLock {
                if (!_ui.value.active) return@launch
                _ui.update { it.copy(phase = Phase.STOPPING) }
                job?.cancelAndJoin()
                val now = System.currentTimeMillis()
                val summary = c.restore.restoreAll(resolver, now)
                c.context.endSession(now)
                val s = _ui.value
                val g = s.game
                val report = if (g != null) ReportBuilder.build(
                    s.startedAtMs, g.packageName, g.displayName, s.startedAtMs, now, baseline.toList(), optimized.toList(),
                    c.context.history(), lastPlan, summary, lastDiagnoses,
                ) else null
                if (report != null) try { c.reports.save(report) } catch (_: Exception) { }
                SessionService.stop(c.app)
                _ui.value = SessionUiState(lastReport = report ?: s.lastReport, pendingRestore = c.restore.pendingCount(), lastRestore = summary, usageAccess = c.foreground.hasAccess())
            }
        }
    }

    /** Manual RESTORE EVERYTHING: ends any running session first, then restores whatever is journaled. */
    fun restoreEverything() {
        if (_ui.value.active) { stop(); return }
        c.scope.launch { restoreEverythingNow() }
    }

    private suspend fun restoreEverythingNow() {
        c.bridge.refresh()
        val summary = c.restore.restoreAll(resolver, System.currentTimeMillis())
        _ui.update { it.copy(pendingRestore = c.restore.pendingCount(), lastRestore = summary) }
    }

    /** Metrics + context history of the finished/ongoing session, for Perfetto export. */
    fun exportTrace(): String = TraceExporter.export(baseline + optimized, c.context.history())

    companion object { const val WARMUP_MS = 20_000L }
}
