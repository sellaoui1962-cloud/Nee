package com.nexora.x.shizuku;

interface IUserService {
    // Transaction id required by Shizuku for the user-service destroy call.
    void destroy() = 16777114;

    // args joined by the unit separator (\u001f). Returns "exit=<code>\n<combined output>".
    String run(String joinedArgs) = 1;
}
