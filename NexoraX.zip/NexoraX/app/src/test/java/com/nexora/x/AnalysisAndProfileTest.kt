package com.nexora.x

import com.nexora.x.analysis.*
import com.nexora.x.model.*
import com.nexora.x.profiles.*
import com.nexora.x.thermal.ThermalPolicy
import org.junit.Assert.*
import org.junit.Test

class AnalysisAndProfileTest {
    private fun m(thermal: ThermalLevel = ThermalLevel.NORMAL, avail: Long? = 2000, total: Long? = 6000, jank: Float? = null,
                  lat: Float? = null, net: Boolean? = true, low: Boolean? = false, cpu: Float? = null, loss: Float? = null) =
        Metrics(atMs = 0, availMemMb = avail, totalMemMb = total, lowMemory = low, thermal = thermal, networkAvailable = net,
            latencyMs = lat, jankPct = jank, processCpuPct = cpu, lossPct = loss)

    @Test fun severeThermalIsHighConfidenceAndFirst() {
        val d = BottleneckAnalyzer.analyze(listOf(m(thermal = ThermalLevel.SEVERE, lat = 300f)))
        assertEquals(BottleneckKind.THERMAL_THROTTLING, d.first().kind); assertEquals(Confidence.HIGH, d.first().confidence)
    }

    @Test fun networkProblemDoesNotBlameCpuOrThermal() {
        val d = BottleneckAnalyzer.analyze(listOf(m(lat = 250f)))
        assertEquals(listOf(BottleneckKind.NETWORK_INSTABILITY), d.map { it.kind })
    }

    @Test fun lowMemoryFlagIsHighConfidenceMemoryPressure() {
        val d = BottleneckAnalyzer.analyze(listOf(m(low = true)))
        assertEquals(BottleneckKind.MEMORY_PRESSURE, d.first().kind); assertEquals(Confidence.HIGH, d.first().confidence)
    }

    @Test fun jankWithoutOtherCauseIsLowConfidenceRenderingNeverCpu() {
        val d = BottleneckAnalyzer.analyze(listOf(m(jank = 20f)))
        assertEquals(BottleneckKind.APP_RENDERING, d.first().kind); assertEquals(Confidence.LOW, d.first().confidence)
        assertTrue(d.none { it.kind == BottleneckKind.CPU || it.kind == BottleneckKind.GPU })
    }

    @Test fun cpuIsOnlyDiagnosedFromARealMeasurement() {
        assertTrue(BottleneckAnalyzer.analyze(listOf(m(cpu = null))).none { it.kind == BottleneckKind.CPU })
        assertTrue(BottleneckAnalyzer.analyze(listOf(m(cpu = 95f))).any { it.kind == BottleneckKind.CPU })
    }

    @Test fun noDataIsInsufficientNotInvented() {
        val d = BottleneckAnalyzer.analyze(listOf(Metrics(atMs = 0)))
        assertEquals(BottleneckKind.INSUFFICIENT_DATA, d.first().kind)
        assertEquals(BottleneckKind.INSUFFICIENT_DATA, BottleneckAnalyzer.analyze(emptyList()).first().kind)
    }

    @Test fun healthyMetricsGiveNone() {
        assertEquals(BottleneckKind.NONE, BottleneckAnalyzer.analyze(listOf(m(jank = 1f))).first().kind)
    }

    @Test fun thermalLevelMappingAndUnknownIsNeverAtLeast() {
        assertEquals(ThermalLevel.NORMAL, ThermalLevel.fromAndroidStatus(0)); assertEquals(ThermalLevel.SEVERE, ThermalLevel.fromAndroidStatus(3))
        assertEquals(ThermalLevel.EMERGENCY, ThermalLevel.fromAndroidStatus(6)); assertEquals(ThermalLevel.UNKNOWN, ThermalLevel.fromAndroidStatus(99))
        assertFalse(ThermalLevel.UNKNOWN.atLeast(ThermalLevel.NORMAL))
    }

    @Test fun thermalCapsProfiles() {
        assertEquals(OptimizationProfile.LOW_HEAT, ThermalPolicy.cap(OptimizationProfile.GAMEPLAY_TURBO, ThermalLevel.SEVERE))
        assertEquals(OptimizationProfile.BALANCED, ThermalPolicy.cap(OptimizationProfile.GAMEPLAY_TURBO, ThermalLevel.MODERATE))
        assertEquals(OptimizationProfile.GAMEPLAY_TURBO, ThermalPolicy.cap(OptimizationProfile.GAMEPLAY_TURBO, ThermalLevel.LIGHT))
        assertEquals(OptimizationProfile.BATTERY_FRIENDLY, ThermalPolicy.cap(OptimizationProfile.BATTERY_FRIENDLY, ThermalLevel.CRITICAL))
        assertEquals(OptimizationProfile.LOW_HEAT, ThermalPolicy.cap(OptimizationProfile.GAMEPLAY_TURBO, ThermalLevel.MODERATE, conservative = true))
        assertFalse(ThermalPolicy.allowsAggressive(ThermalLevel.MODERATE))
    }

    @Test fun smartAutoIsConservativeWhenUnsure() {
        val p = ProfileResolver.resolve(OptimizationProfile.SMART_AUTO, GameState.GAMEPLAY, 0.25f, ThermalLevel.NORMAL)
        assertEquals(OptimizationProfile.BALANCED, p)
        assertEquals(OptimizationProfile.GAMEPLAY_TURBO, ProfileResolver.resolve(OptimizationProfile.SMART_AUTO, GameState.GAMEPLAY, 0.9f, ThermalLevel.NORMAL))
        assertEquals(OptimizationProfile.ROOM_FOCUS, ProfileResolver.resolve(OptimizationProfile.SMART_AUTO, GameState.ROOM, 0.9f, ThermalLevel.NORMAL))
        assertEquals(OptimizationProfile.ROOM_FOCUS, ProfileResolver.resolve(OptimizationProfile.SMART_AUTO, GameState.UNKNOWN, 0.25f, ThermalLevel.NORMAL, roomFocusActive = true))
        assertEquals(OptimizationProfile.LOW_HEAT, ProfileResolver.resolve(OptimizationProfile.SMART_AUTO, GameState.GAMEPLAY, 0.9f, ThermalLevel.SEVERE))
    }

    @Test fun gameModeMapping() {
        assertEquals(GameModeValue.PERFORMANCE, ProfileResolver.gameModeFor(OptimizationProfile.GAMEPLAY_TURBO, GraphicsProfile.BALANCED))
        assertEquals(GameModeValue.BATTERY, ProfileResolver.gameModeFor(OptimizationProfile.LOW_HEAT, GraphicsProfile.BALANCED))
        assertNull(ProfileResolver.gameModeFor(OptimizationProfile.ROOM_FOCUS, GraphicsProfile.PERFORMANCE))
        assertEquals(GameModeValue.PERFORMANCE, ProfileResolver.gameModeFor(OptimizationProfile.CUSTOM, GraphicsProfile.PERFORMANCE))
        assertNull(ProfileResolver.gameModeFor(OptimizationProfile.CUSTOM, GraphicsProfile.BALANCED))
    }

    @Test fun planNeverShowsUnsupportedAsActive() {
        val noShizuku = DeviceCaps(sdk = 34, gameModeApi = true, thermalApi = true, shizukuReady = false, usageAccess = true)
        val plan = ProfileEngine.plan(OptimizationProfile.GAMEPLAY_TURBO, GraphicsProfile.BALANCED, noShizuku, ActionStatus.ACTIVE).associate { it.id to it.status }
        assertEquals(ActionStatus.REQUIRES_PERMISSION, plan[ActionIds.GAME_MODE])
        assertEquals(ActionStatus.UNAVAILABLE, plan[ActionIds.ADPF])
        val old = DeviceCaps(sdk = 28, gameModeApi = false, thermalApi = false, shizukuReady = true, usageAccess = true)
        val p2 = ProfileEngine.plan(OptimizationProfile.GAMEPLAY_TURBO, GraphicsProfile.BALANCED, old, ActionStatus.ACTIVE).associate { it.id to it.status }
        assertEquals(ActionStatus.UNAVAILABLE, p2[ActionIds.GAME_MODE]); assertEquals(ActionStatus.UNAVAILABLE, p2[ActionIds.THERMAL_GUARD])
    }
}
