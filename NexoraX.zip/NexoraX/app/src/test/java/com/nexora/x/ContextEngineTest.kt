package com.nexora.x

import com.nexora.x.context.*
import com.nexora.x.model.*
import org.junit.Assert.*
import org.junit.Test

class ContextEngineTest {
    private fun fg(t: Long, v: Boolean) = ContextSignal(SignalSource.FOREGROUND_PACKAGE, null, 0.9f, t, gameForeground = v)
    private fun engine() = ContextEngine().also { it.startSession(0) }

    @Test fun foregroundOnlyIsUnknownWithLowConfidence() {
        val e = engine(); e.submit(fg(1_000, true))
        val s = e.evaluate(20_000)
        assertEquals(GameState.UNKNOWN, s.state)
        assertEquals(0.25f, s.confidence, 0.001f)
        assertEquals(SignalSource.FOREGROUND_PACKAGE, s.source)
    }

    @Test fun backgroundWhenGameNotForeground() {
        val e = engine(); e.submit(fg(1_000, false))
        assertEquals(GameState.BACKGROUND, e.evaluate(2_000).state)
    }

    @Test fun appStartingOnlyAfterSeeingBackgroundThenForeground() {
        val e = engine(); e.submit(fg(1_000, false)); e.submit(fg(2_000, true))
        assertEquals(GameState.APP_STARTING, e.evaluate(3_000).state)
        assertEquals(GameState.UNKNOWN, e.evaluate(9_000).state)
    }

    @Test fun noForegroundInformationIsVeryLowConfidenceUnknown() {
        val s = engine().evaluate(1_000)
        assertEquals(GameState.UNKNOWN, s.state)
        assertEquals(0.1f, s.confidence, 0.001f)
        assertNull(s.gameForeground)
    }

    @Test fun activityRuleSignalGivesState() {
        val e = engine(); e.submit(fg(1_000, true))
        e.submit(ContextSignal(SignalSource.ACTIVITY_RULE, GameState.ROOM, 0.8f, 1_500, ttlMs = 0))
        val s = e.evaluate(2_000)
        assertEquals(GameState.ROOM, s.state); assertEquals(0.8f, s.confidence, 0.001f)
    }

    @Test fun manualStateBeatsOtherSignals() {
        val e = engine(); e.submit(fg(1_000, true))
        e.submit(ContextSignal(SignalSource.ACTIVITY_RULE, GameState.GAMEPLAY, 0.8f, 1_500, ttlMs = 0))
        e.submit(ContextSignal(SignalSource.MANUAL, GameState.ROOM, 1f, 1_600, ttlMs = 0))
        val s = e.evaluate(2_000)
        assertEquals(GameState.ROOM, s.state); assertEquals(SignalSource.MANUAL, s.source)
    }

    @Test fun manualStateWorksWithoutForegroundInfo() {
        val e = engine()
        e.submit(ContextSignal(SignalSource.MANUAL, GameState.GAMEPLAY, 1f, 100, ttlMs = 0))
        assertEquals(GameState.GAMEPLAY, e.evaluate(200).state)
    }

    @Test fun expiredSignalIsIgnored() {
        val e = engine(); e.submit(fg(1_000, true))
        e.submit(ContextSignal(SignalSource.AUDIO_MODE, GameState.VOICE_CHAT, 0.6f, 1_000, ttlMs = 1_000))
        assertEquals(GameState.VOICE_CHAT, e.evaluate(1_500).state)
        assertEquals(GameState.UNKNOWN, e.evaluate(5_000).state)
    }

    @Test fun backgroundClearsAutomaticSignalsButKeepsManual() {
        val e = engine(); e.submit(fg(1_000, true))
        e.submit(ContextSignal(SignalSource.ACTIVITY_RULE, GameState.ROOM, 0.8f, 1_100, ttlMs = 0))
        e.submit(fg(2_000, false)); e.submit(fg(3_000, true))
        assertNotEquals(GameState.ROOM, e.evaluate(20_000).state)
    }

    @Test fun lowConfidenceBlocksQuietTimeWork() {
        val low = StatePolicy.allowedOps(GameState.UNKNOWN, 0.25f)
        assertTrue(OpKind.THERMAL_MONITOR in low)
        assertFalse(OpKind.ANALYTICS_WRITE in low); assertFalse(OpKind.HEAVY_UI in low)
        assertTrue(OpKind.ANALYTICS_WRITE in StatePolicy.allowedOps(GameState.HOME, 0.9f))
    }

    @Test fun noNetworkProbeDuringRoomGameplayOrVoice() {
        listOf(GameState.ROOM, GameState.GAMEPLAY, GameState.VOICE_CHAT, GameState.LOADING).forEach {
            assertNull(StatePolicy.networkProbeIntervalMs(it, 0.9f))
            assertFalse(OpKind.NETWORK_PROBE in StatePolicy.allowedOps(it, 0.9f))
        }
    }

    @Test fun roomIsMonitoredLessOftenThanLobby() {
        assertTrue(StatePolicy.monitoringIntervalMs(GameState.ROOM) > StatePolicy.monitoringIntervalMs(GameState.LOBBY))
    }

    @Test fun historyRecordsEntryAndExit() {
        val e = engine(); e.submit(fg(1_000, true)); e.evaluate(2_000)
        e.submit(fg(3_000, false)); e.evaluate(3_000)
        e.endSession(9_000)
        val h = e.history()
        assertTrue(h.all { it.exitedAtMs != null })
        assertEquals(GameState.IDLE, h.last().state)
    }

    @Test fun activityRuleMatcherIsCaseInsensitiveAndIgnoresBlank() {
        val rules = listOf(ActivityRule("GameActivity", GameState.GAMEPLAY), ActivityRule("", GameState.HOME))
        assertEquals(GameState.GAMEPLAY, ActivityRuleMatcher.match("com.x.gameactivity", rules))
        assertNull(ActivityRuleMatcher.match("com.x.Other", rules))
        assertNull(ActivityRuleMatcher.match(null, rules))
    }
}
