package com.nexora.x

import com.nexora.x.context.ContextSnapshot
import com.nexora.x.context.RoomFocusEngine
import com.nexora.x.model.*
import org.junit.Assert.*
import org.junit.Test

class RoomFocusEngineTest {
    private fun snap(state: GameState, conf: Float) =
        ContextSnapshot(state, conf, SignalSource.ACTIVITY_RULE, 0, true, 1_000, emptySet(), emptySet(), null)

    @Test fun reliableRoomEntersThenBecomesActive() {
        val r = RoomFocusEngine()
        assertEquals(RoomState.ROOM_ENTERING, r.update(snap(GameState.ROOM, 0.9f)))
        assertFalse(r.focusActive)
        assertEquals(RoomState.ROOM_ACTIVE, r.update(snap(GameState.ROOM, 0.9f)))
        assertTrue(r.focusActive)
    }

    @Test fun unreliableRoomNeverActivatesFocus() {
        val r = RoomFocusEngine()
        repeat(3) { assertEquals(RoomState.ROOM_IDLE, r.update(snap(GameState.ROOM, 0.5f))) }
        assertFalse(r.focusActive)
    }

    @Test fun unknownStateDoesNotInventARoom() {
        val r = RoomFocusEngine()
        assertEquals(RoomState.ROOM_UNKNOWN, r.update(snap(GameState.UNKNOWN, 0.25f)))
    }

    @Test fun manualToggleActivatesEvenWhenStateUnknown() {
        val r = RoomFocusEngine(); r.manualRoomFocus = true
        assertEquals(RoomState.ROOM_ACTIVE, r.update(snap(GameState.UNKNOWN, 0.25f)))
        assertTrue(r.focusActive)
    }

    @Test fun loadingInsideRoomIsATransition() {
        val r = RoomFocusEngine(); r.update(snap(GameState.ROOM, 0.9f)); r.update(snap(GameState.ROOM, 0.9f))
        assertEquals(RoomState.ROOM_TRANSITION, r.update(snap(GameState.LOADING, 0.9f)))
        assertFalse(r.focusActive)
    }

    @Test fun leavingRoomGoesThroughExiting() {
        val r = RoomFocusEngine(); r.update(snap(GameState.ROOM, 0.9f)); r.update(snap(GameState.ROOM, 0.9f))
        assertEquals(RoomState.ROOM_EXITING, r.update(snap(GameState.LOBBY, 0.9f)))
        assertEquals(RoomState.ROOM_UNKNOWN, r.update(snap(GameState.LOBBY, 0.9f)))
    }

    @Test fun voiceChatInsideRoomKeepsFocus() {
        val r = RoomFocusEngine(); r.update(snap(GameState.ROOM, 0.9f)); r.update(snap(GameState.ROOM, 0.9f))
        assertEquals(RoomState.ROOM_VOICE_ACTIVE, r.update(snap(GameState.VOICE_CHAT, 0.6f)))
        assertTrue(r.focusActive)
    }

    @Test fun backgroundResetsRoomState() {
        val r = RoomFocusEngine(); r.manualRoomFocus = true; r.update(snap(GameState.UNKNOWN, 0.25f))
        assertEquals(RoomState.ROOM_UNKNOWN, r.update(snap(GameState.BACKGROUND, 0.9f)))
    }
}
