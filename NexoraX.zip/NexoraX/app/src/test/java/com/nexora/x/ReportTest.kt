package com.nexora.x

import com.nexora.x.analysis.Metrics
import com.nexora.x.context.StateTransition
import com.nexora.x.model.*
import com.nexora.x.restore.RestoreSummary
import com.nexora.x.session.*
import org.junit.Assert.*
import org.junit.Test

class ReportTest {
    private fun m(t: Long, jank: Float? = null, mem: Long? = null, th: ThermalLevel = ThermalLevel.NORMAL) =
        Metrics(atMs = t, jankPct = jank, availMemMb = mem, thermal = th)

    @Test fun verdictRequiresARealChange() {
        assertEquals(Verdict.IMPROVED, ReportBuilder.verdict(20f, 10f, lowerIsBetter = true))
        assertEquals(Verdict.WORSE, ReportBuilder.verdict(10f, 20f, lowerIsBetter = true))
        assertEquals(Verdict.NO_CHANGE, ReportBuilder.verdict(20f, 19.8f, lowerIsBetter = true))
        assertEquals(Verdict.IMPROVED, ReportBuilder.verdict(1000f, 1500f, lowerIsBetter = false, minAbs = 50f))
        assertEquals(Verdict.NOT_COMPARABLE, ReportBuilder.verdict(null, 5f, lowerIsBetter = true))
    }

    @Test fun tooFewSamplesMeansNothingIsReportedAsImproved() {
        val r = ReportBuilder.build(1, "a.b", "A", 0, 100, listOf(m(1, 30f)), listOf(m(2, 5f)), emptyList(), emptyList(), RestoreSummary(), emptyList())
        assertTrue(r.comparisons.all { it.verdict == Verdict.NOT_COMPARABLE })
        assertTrue("insufficient_samples" in r.notes)
    }

    @Test fun enoughSamplesCanShowAnImprovement() {
        val before = (1..4).map { m(it.toLong(), 30f) }; val after = (5..8).map { m(it.toLong(), 10f) }
        val r = ReportBuilder.build(1, "a.b", "A", 0, 100, before, after, emptyList(), emptyList(), RestoreSummary(), emptyList())
        assertEquals(Verdict.IMPROVED, r.comparisons.first { it.metric == "jank_pct" }.verdict)
        assertEquals(Verdict.NOT_COMPARABLE, r.comparisons.first { it.metric == "latency_ms" }.verdict) // no data => no claim
    }

    @Test fun aggregateIgnoresMissingValuesAndFindsMaxThermal() {
        val a = ReportBuilder.aggregate(listOf(m(1, null, null, ThermalLevel.UNKNOWN), m(2, 12f, 1000, ThermalLevel.MODERATE), m(3, 8f, 2000, ThermalLevel.LIGHT)))
        assertEquals(10f, a.avgJankPct!!, 0.001f); assertEquals(1500f, a.avgAvailMemMb!!, 0.001f)
        assertEquals(ThermalLevel.MODERATE, a.maxThermal); assertEquals(1, a.stutterIntervals)
        assertNull(ReportBuilder.aggregate(emptyList()).avgJankPct)
        assertEquals(ThermalLevel.UNKNOWN, ReportBuilder.aggregate(emptyList()).maxThermal)
    }

    @Test fun timeInStateSumsDurations() {
        val h = listOf(
            StateTransition(GameState.LOBBY, 0.9f, SignalSource.MANUAL, 0, 1_000),
            StateTransition(GameState.ROOM, 0.9f, SignalSource.MANUAL, 1_000, 4_000),
            StateTransition(GameState.LOBBY, 0.9f, SignalSource.MANUAL, 4_000, null),
        )
        val t = ReportBuilder.timeInState(h, 6_000)
        assertEquals(3_000L, t[GameState.LOBBY]); assertEquals(3_000L, t[GameState.ROOM])
    }

    @Test fun traceExportContainsCountersAndStateMarkersAndSkipsUnknowns() {
        val json = TraceExporter.export(
            listOf(m(1_000, 5f, 900, ThermalLevel.NORMAL), m(2_000, null, null, ThermalLevel.UNKNOWN)),
            listOf(StateTransition(GameState.ROOM, 0.9f, SignalSource.MANUAL, 1_500, null)),
        )
        assertTrue(json.contains("\"traceEvents\"")); assertTrue(json.contains("jank_pct")); assertTrue(json.contains("state:ROOM"))
        assertEquals(1, Regex("\"name\":\"jank_pct\"").findAll(json).count())
        assertEquals(1, Regex("\"name\":\"thermal_level\"").findAll(json).count())
    }
}
