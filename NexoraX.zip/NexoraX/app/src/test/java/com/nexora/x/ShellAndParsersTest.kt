package com.nexora.x

import com.nexora.x.analysis.*
import com.nexora.x.shizuku.GameModeParser
import com.nexora.x.shizuku.ShellAllowlist
import org.junit.Assert.*
import org.junit.Test

class ShellAndParsersTest {
    private val pkg = "com.example.game"

    @Test fun allowlistAcceptsOnlyTheThreeSupportedCommands() {
        assertTrue(ShellAllowlist.validate(ShellAllowlist.gameModeSet(pkg, "performance", 0)))
        assertTrue(ShellAllowlist.validate(ShellAllowlist.gameModeGet(pkg, 0)))
        assertTrue(ShellAllowlist.validate(ShellAllowlist.gfxInfo(pkg)))
    }

    @Test fun allowlistRejectsInjectionAndUnknownCommands() {
        assertFalse(ShellAllowlist.validate(listOf("rm", "-rf", "/")))
        assertFalse(ShellAllowlist.validate(listOf("am", "force-stop", pkg)))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gameModeSet("com.x;reboot", "performance", 0)))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gameModeSet("$pkg --user 5", "performance", 0)))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gameModeSet(pkg, "custom", 0)))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gameModeSet(pkg, "performance; id", 0)))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gfxInfo("-h")))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gfxInfo("nodots")))
        assertFalse(ShellAllowlist.validate(ShellAllowlist.gfxInfo(pkg) + "reset"))
        assertFalse(ShellAllowlist.validate(emptyList()))
    }

    @Test fun gameModeParserHandlesSeveralOutputShapes() {
        assertEquals("performance", GameModeParser.parse("com.example.game current mode: performance, available: [standard, battery]"))
        assertEquals("battery", GameModeParser.parse("battery\n"))
        assertEquals("standard", GameModeParser.parse("1"))
        assertEquals("performance", GameModeParser.parse("2\n"))
        assertNull(GameModeParser.parse("Error: unknown command"))
        assertNull(GameModeParser.parse(""))
    }

    private val gfx = """
        Stats since: 123456789ns
        Total frames rendered: 1000
        Janky frames: 120 (12.00%)
        50th percentile: 8ms
        90th percentile: 17ms
        95th percentile: 24ms
        99th percentile: 48ms
    """.trimIndent()

    @Test fun gfxInfoParserReadsTotalsAndPercentiles() {
        val s = GfxInfoParser.parse(gfx)!!
        assertEquals(1000L, s.totalFrames); assertEquals(120L, s.jankyFrames); assertEquals(24, s.p95Ms); assertEquals(8, s.p50Ms)
    }

    @Test fun gfxInfoParserReturnsNullWhenGameDoesNotUseHwui() {
        assertNull(GfxInfoParser.parse("Total frames rendered: 0\nJanky frames: 0 (0.00%)"))
        assertNull(GfxInfoParser.parse("No process found"))
    }

    @Test fun intervalJankUsesDeltasAndRefusesTinyOrResetSamples() {
        val a = FrameStats(1000, 120, null, null, null, null)
        assertEquals(15f, GfxInfoParser.intervalJankPct(a, FrameStats(1100, 135, null, null, null, null))!!, 0.001f)
        assertNull(GfxInfoParser.intervalJankPct(a, FrameStats(1010, 130, null, null, null, null)))
        assertNull(GfxInfoParser.intervalJankPct(a, FrameStats(50, 1, null, null, null, null)))
        assertNull(GfxInfoParser.intervalJankPct(null, a))
    }

    @Test fun latencySamplerComputesAverageJitterAndLoss() {
        val s = LatencySampler(10); s.add(10f); s.add(20f); s.add(null)
        val st = s.stats()
        assertEquals(15f, st.avgMs!!, 0.001f); assertEquals(10f, st.jitterMs!!, 0.001f); assertEquals(33.33f, st.lossPct!!, 0.01f)
        assertNull(LatencySampler().stats().avgMs)
    }

    @Test fun latencySamplerKeepsOnlyTheWindow() {
        val s = LatencySampler(3); repeat(10) { s.add(it.toFloat()) }
        assertEquals(3, s.stats().count)
    }
}
