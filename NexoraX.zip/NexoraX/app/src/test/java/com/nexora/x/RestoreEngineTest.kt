package com.nexora.x

import com.nexora.x.restore.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

private class FakeStore : JournalStore {
    var data: List<JournalEntry> = emptyList()
    override fun load() = data
    override fun save(entries: List<JournalEntry>) { data = entries }
}

private class FakeAdapter(override val id: String, var value: String?, var ignoreWrite: Boolean = false, var failWrite: Boolean = false) : SettingAdapter {
    override suspend fun read() = value
    override suspend fun write(value: String): Boolean {
        if (failWrite) return false
        if (!ignoreWrite) this.value = value
        return true
    }
}

class RestoreEngineTest {
    private val id = "game_mode:com.example.game"
    private fun resolver(a: SettingAdapter?) = AdapterResolver { if (it == id) a else null }

    @Test fun appliesThenRestoresOriginal() = runBlocking {
        val a = FakeAdapter(id, "standard"); val e = RestoreEngine(FakeStore())
        assertEquals(ApplyResult.APPLIED, e.apply(a, "performance", "test", 1))
        assertEquals("performance", a.value); assertEquals(1, e.pendingCount())
        val s = e.restoreAll(resolver(a), 2)
        assertEquals("standard", a.value); assertEquals(1, s.restored); assertEquals(0, e.pendingCount())
    }

    @Test fun sameValueIsNotJournaled() = runBlocking {
        val a = FakeAdapter(id, "performance"); val e = RestoreEngine(FakeStore())
        assertEquals(ApplyResult.ALREADY_SET, e.apply(a, "performance", "test", 1))
        assertEquals(0, e.pendingCount())
    }

    @Test fun unreadableSettingIsUnsupportedAndUntouched() = runBlocking {
        val a = FakeAdapter(id, null); val e = RestoreEngine(FakeStore())
        assertEquals(ApplyResult.UNSUPPORTED, e.apply(a, "performance", "test", 1)); assertNull(a.value)
    }

    @Test fun neverOverwritesAValueTheUserChangedMeanwhile() = runBlocking {
        val a = FakeAdapter(id, "standard"); val e = RestoreEngine(FakeStore())
        e.apply(a, "performance", "test", 1)
        a.value = "battery" // the user changed it during the session
        val s = e.restoreAll(resolver(a), 2)
        assertEquals("battery", a.value); assertEquals(1, s.userChanged); assertEquals(0, s.restored); assertEquals(0, e.pendingCount())
    }

    @Test fun failedVerificationRevertsAndJournalsNothing() = runBlocking {
        val a = FakeAdapter(id, "standard", ignoreWrite = true); val e = RestoreEngine(FakeStore())
        assertEquals(ApplyResult.VERIFY_FAILED_REVERTED, e.apply(a, "performance", "test", 1))
        assertEquals("standard", a.value); assertEquals(0, e.pendingCount())
    }

    @Test fun failedWriteIsReportedAndNotJournaled() = runBlocking {
        val a = FakeAdapter(id, "standard", failWrite = true); val e = RestoreEngine(FakeStore())
        assertEquals(ApplyResult.WRITE_FAILED, e.apply(a, "performance", "test", 1)); assertEquals(0, e.pendingCount())
    }

    @Test fun switchingBetweenModesKeepsTheTrueOriginal() = runBlocking {
        val a = FakeAdapter(id, "standard"); val e = RestoreEngine(FakeStore())
        e.apply(a, "performance", "p", 1); e.apply(a, "battery", "thermal", 2)
        assertEquals(1, e.pendingCount())
        e.restoreAll(resolver(a), 3)
        assertEquals("standard", a.value)
    }

    @Test fun journalSurvivesProcessDeathAndReboot() = runBlocking {
        val store = FakeStore(); val a = FakeAdapter(id, "standard")
        RestoreEngine(store).apply(a, "performance", "test", 1) // process "dies" here
        val revived = RestoreEngine(store)
        assertEquals(1, revived.pendingCount())
        revived.restoreAll(resolver(a), 5)
        assertEquals("standard", a.value); assertEquals(0, revived.pendingCount())
    }

    @Test fun staysPendingWhenShizukuIsUnavailable() = runBlocking {
        val a = FakeAdapter(id, "standard"); val e = RestoreEngine(FakeStore())
        e.apply(a, "performance", "test", 1)
        val s = e.restoreAll(resolver(null), 2)
        assertEquals(1, s.unavailable); assertEquals(1, e.pendingCount()); assertEquals("performance", a.value)
        e.restoreAll(resolver(a), 3) // Shizuku came back
        assertEquals("standard", a.value); assertEquals(0, e.pendingCount())
    }

    @Test fun doesNothingForSettingsItNeverChanged() = runBlocking {
        val a = FakeAdapter(id, "performance"); val e = RestoreEngine(FakeStore())
        val s = e.restoreAll(resolver(a), 1)
        assertEquals(RestoreSummary(), s); assertEquals("performance", a.value)
    }

    @Test fun restoreOneOnlyTouchesThatSetting() = runBlocking {
        val a = FakeAdapter(id, "standard"); val b = FakeAdapter("game_mode:com.other.game", "standard"); val e = RestoreEngine(FakeStore())
        e.apply(a, "performance", "t", 1); e.apply(b, "performance", "t", 1)
        e.restoreOne(AdapterResolver { if (it == id) a else b }, id, 2)
        assertEquals("standard", a.value); assertEquals("performance", b.value); assertEquals(1, e.pendingCount())
    }
}
