# IMPLEMENTATION_ROADMAP

Legend: **Written** = code exists, desk-checked, *not compiled or run by the author*. **Not done** = not implemented.

| Phase | Scope | Status |
|---|---|---|
| 1 | Audit and architecture docs | Written (no prior project existed; see PROJECT_ANALYSIS) |
| 2 | Shizuku integration, permissions | Written (bridge, UserService, allowlist, Shizuku Center screen) |
| 3 | Game detection, session manager | Written |
| 4 | Context Intelligence Engine | Written + unit tests |
| 5 | Resource Priority Engine | Written (NEXORA self-reduction via policy; no foreign CPU/GPU control by design) |
| 6 | Thermal Guardian | Written + unit tests |
| 7 | Anti-Stutter Engine | Partial: jank sampling via gfxinfo, stutter intervals, before/after comparison; no automatic mitigation beyond profile switching |
| 8 | Room Focus Engine | Written + unit tests |
| 9 | Adaptive Graphics Engine | Partial: Game Mode intervention with disclosure + restore; capability readout; no resolution changes (by design) |
| 10 | Audio and Network Guardians | Written (observation-only audio; passive network + optional probe) |
| 11 | Restore Engine | Written + unit tests (incl. user-change protection, crash recovery) |
| 12 | Performance Lab | Written (baseline vs optimized, verdict thresholds, Perfetto-compatible JSON export) |
| 13 | UI polish and localization | Partial: 13 screens, en/ar strings, RTL via system; no visual QA done |
| 14 | Testing and release build | **Not done**: JVM unit tests written, never run; no instrumented tests; no APK built |

## Next steps (on your machine)
1. Open in Android Studio (Ladybug+), let it sync (it creates the Gradle wrapper JAR).
2. `./gradlew testDebugUnitTest` then `./gradlew assembleRelease`. Send me the first errors if any.
3. Install Shizuku, grant NEXORA permission, grant Usage access, select Yalla Ludo, add Activity rules after
   watching "Foreground Activity class" on the Context screen while moving between lobby/room/game.
4. Validate `cmd game mode` output and gfxinfo on your device (Shizuku Center log + Graphics screen).
