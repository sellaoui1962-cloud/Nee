# ARCHITECTURE

Single module, layered by package (UI -> session -> engines -> platform adapters). Engines are pure Kotlin
(no Android imports) so they are unit-testable on the JVM.

```
ui/            Compose screens, MainViewModel (observes flows, no system calls)
session/       SessionManager (orchestrator), SessionService (FGS), SessionReport/ReportBuilder/TraceExporter
context/       ContextEngine (state machine + confidence), StatePolicy, RoomFocusEngine, ActivityRuleMatcher   [pure]
analysis/      Metrics, BottleneckAnalyzer, GfxInfoParser, LatencySampler                                       [pure]
profiles/      ProfileResolver, ProfileEngine (honest action statuses)                                           [pure]
thermal/       ThermalPolicy [pure], ThermalGuardian (PowerManager thermal API)
restore/       RestoreEngine + journal (read -> journal -> write -> verify -> revert)                            [pure]
shizuku/       ShellAllowlist, GameModeParser [pure]; ShizukuBridge, PrivilegedService (UserService), AIDL
monitor/       ForegroundDetector (UsageStats), NetworkGuardian, AudioGuardian, MetricsCollector
capability/    CapabilityDetector
data/          ProfileStore, SettingsStore, GameRepository, ReportStore, JournalPrefsStore
```

## Session flow
select game -> start (FGS + passive monitors) -> WARMUP (collect baseline while the game is in the foreground, 20 s)
-> OPTIMIZING (apply profile through RestoreEngine) -> adaptive loop -> stop / auto-end -> restoreAll -> report.

The loop interval comes from `StatePolicy`, so NEXORA's own workload shrinks in room/gameplay
(15 s / 10 s vs 5 s in menus), network probes are disabled in room/gameplay/voice/loading, and analytics/DB writes
only happen in quiet states. Reports are written once, at session end.

## Context engine
Sources: foreground package (0.9), user Activity rules (0.8), audio call-mode hint (0.6), manual (1.0).
Only the foreground package => `UNKNOWN`, confidence 0.25. Below 0.5 confidence the policy removes "quiet time" work
and `SMART_AUTO` resolves to `BALANCED`. Room Focus activates automatically only at confidence >= 0.7 for `ROOM`,
or manually.

## Safety design
* Every privileged call goes through `ShellAllowlist` (3 command shapes, strict regex), checked in the app **and**
  again inside the privileged process.
* `RestoreEngine`: journal persisted synchronously on each change; restore never overwrites a value the user changed;
  stale/unreadable settings stay pending and are retried when Shizuku becomes READY again (crash, reboot and
  Shizuku-reconnect recovery). Manual "RESTORE EVERYTHING" is on the dashboard and settings.
* Thermal level can only make profiles more conservative (`ThermalPolicy`); SEVERE+ forces a battery-oriented mode
  and bypasses the transient-state gate. Thermal protection is never touched.
* No code injection, no process killing, no private game files, no traffic interception, no CPU/GPU tuning.
