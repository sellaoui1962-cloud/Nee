# CAPABILITY_MATRIX

| Capability | Status | Needs | Notes |
|---|---|---|---|
| Installed game list, search, icons, per-game profile | Fully supported | - | Launcher-intent query, no QUERY_ALL_PACKAGES |
| Foreground game detection | Fully supported | Usage access (user-granted) | Polled at policy interval |
| Detailed screen state (lobby/room/gameplay) | **Partial / device-and-game dependent** | User Activity rules or manual state | A normal app cannot read a game's private screens; otherwise UNKNOWN |
| Room Focus (reduce NEXORA's own load) | Fully supported | Reliable ROOM signal (>= 0.7) or manual toggle | Does not alter the game |
| Thermal status | Supported on Android 10+ | - | UNKNOWN below Android 10 |
| Battery temperature, available RAM, low-memory flag | Fully supported | - | Standard APIs |
| Network type/availability | Fully supported | - | Passive callback |
| Latency / jitter / loss | Supported | User-chosen host, INTERNET | TCP connect time; paused in room/gameplay; never to game servers |
| Voice-chat hint | Partial | - | AudioManager mode; any VoIP app triggers it (confidence 0.6) |
| System Game Mode per game (performance/battery) | Device-dependent | Shizuku, Android 12+ | `cmd game set`; unreadable => unsupported => untouched |
| Frame jank statistics | Device/game-dependent | Shizuku | `dumpsys gfxinfo`; 0 frames for non-HWUI games => NOT AVAILABLE |
| Process CPU / GPU utilisation of another app | **Unsupported** | root/special permissions | Always shown NOT AVAILABLE |
| ADPF PerformanceHintManager for another app's threads | **Requires integration by the target game** | Game code | Shown UNAVAILABLE |
| In-game graphics (shaders, textures, resolution) | **Unsupported** | Game exposes options | Never modified |
| Screen resolution / UI scale changes | Not implemented (by design) | - | Spec: preserve |
| CPU governors, core pinning, GPU overclock | **Unsupported / refused** | root | Not attempted |
| Force-stop other apps, RAM "cleaning" | Refused | - | Against the design |
| Audio interruption count | Partial | - | Output-device removals only |
| Perfetto trace | Supported as Chrome-trace JSON | - | Open in ui.perfetto.dev |
| Restore after crash / reboot | Supported | Shizuku running again | Journal-based |
| Arabic / English, RTL | Supported | - | Follows system language |
