# PROJECT_ANALYSIS

## Starting point
No existing NEXORA X source tree was provided (only the two specification documents). The audit of an existing
project (Phase 1, step "inspect every directory") therefore had nothing to inspect, and the project was created
from scratch following the specification. **If you have an older project, send it and the useful parts can be merged.**

## Verification status (read this first)
The authoring sandbox had **no Android SDK, no Gradle, no Kotlin compiler and no network**.
Consequently, **nothing in this repository has been compiled, unit-tested or run on a device by the author.**
The code was written and desk-checked carefully, but the first `./gradlew test` / `assembleDebug` on your machine
may reveal compile errors. Send them back and they are normally quick fixes.

## Deliberate deviations from the specification
| Spec | Done instead | Why |
|---|---|---|
| Multi-module (core-*, feature-*) | Single `app` module, one package per concern | Unverifiable multi-module Gradle + Hilt wiring is the most likely source of build failure; packages map 1:1 to the planned modules and can be split later |
| Hilt + Room | Manual `AppContainer`, SharedPreferences/JSON files | Avoids kapt/KSP setup risk; data is tiny (profiles, journal, reports) |
| Perfetto integration | Chrome-trace JSON export (opens in ui.perfetto.dev) | Real, simple and honest; no native Perfetto SDK |
| In-app language switcher | Follows system language (en/ar, RTL automatic) | Per-app locale needs extra plumbing; system locale is fully supported |
| Dedicated "Gameplay Turbo" screen | Merged into the Profiles screen | Same controls, fewer duplicated screens |
| Release APK | Not produced | Cannot be built without the SDK; release uses the debug key until you add a keystore |
| Instrumented/UI tests (Arabic/RTL) | Not written | Need a device/emulator; only JVM unit tests exist |

## Known risks / things to validate on a real device
1. `cmd game mode` output format differs by Android version/OEM. The parser is tolerant and fails safe
   (unreadable value => "unsupported" => nothing is changed).
2. `dumpsys gfxinfo` only reports frames for apps that render through HWUI. Many games (Unity/Vulkan/GL surfaces)
   report 0 frames, in which case frame metrics show NOT AVAILABLE.
3. UsageStats gives only the foreground package and Activity class. Without user-defined activity rules the state
   is UNKNOWN (0.25), by design.
4. After a reboot, restoration needs Shizuku to be running again (Shizuku itself must be restarted by the user).
5. Shizuku API member names were written from the 13.1.5 API; verify on first compile.
