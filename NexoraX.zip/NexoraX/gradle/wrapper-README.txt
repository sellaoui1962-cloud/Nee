Gradle wrapper JAR is a binary and was not generated in the authoring sandbox (no network).
Generate it with:   gradle wrapper --gradle-version 8.9
or just open the project in Android Studio (Ladybug or newer) which does it for you.
