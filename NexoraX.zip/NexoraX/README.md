# NEXORA X (Android game performance engine)

Context-aware, measurement-based, fully reversible. See `docs/` for the analysis, architecture, capability matrix
and roadmap. **Important: this code has not been compiled or tested yet (see docs/PROJECT_ANALYSIS.md).**

## Build
```
# Android Studio Ladybug+ / JDK 17 / Android SDK 35
./gradlew testDebugUnitTest     # JVM unit tests (context, room focus, analyzer, restore, parsers, reports)
./gradlew assembleDebug         # app/build/outputs/apk/debug
./gradlew assembleRelease       # signed with the DEBUG key: add your own keystore before distributing
```
If `gradlew` is missing, run `gradle wrapper --gradle-version 8.9` or open the folder in Android Studio.

## First run
1. Install Shizuku and start it (wireless debugging or adb). In NEXORA > Shizuku Center, request permission.
2. Settings > Usage access: allow NEXORA (needed to see the foreground game).
3. Game Library: pick the game (e.g. Yalla Ludo), choose Smart Auto.
4. Dashboard > START GAMING SESSION. Open the game. Use Context Intelligence to add Activity rules or set the
   state / Room Focus manually if the screen cannot be detected.
5. Stop the session (or RESTORE NORMAL MODE) to restore every setting NEXORA changed.
